﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;
using System.Windows.Media;
using Bots.DungeonBuddy.Avoidance;
using Bots.DungeonBuddy.Behaviors;
using Bots.DungeonBuddy.Profiles.Handlers;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using AvoidanceManager = Bots.DungeonBuddy.Avoidance.AvoidanceManager;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
	/*
	public class Downfall : Dungeon
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 725; }
		}

		public override WoWPoint Entrance { get { return new WoWPoint(1242.479, 600.5036, 318.0787); } }

		#region Movement

		public override MoveResult MoveTo(WoWPoint location)
		{
			var myLoc = Me.Location;
			
			return MoveResult.Failed;
		}		

		#endregion

		public override void RemoveTargetsFilter(List<WoWObject> units)
		{
			units.RemoveAll(
				ret =>
				{
					var unit = ret.ToUnit();
					if (unit != null)
					{

					}
					return false;
				});
		}

		public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
		{
			foreach (var obj in incomingunits)
			{
				var unit = obj as WoWUnit;
				if (unit != null)
				{
				}
			}
		}

		public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
		{
			foreach (var priority in units)
			{
				var unit = priority.Object as WoWUnit;
				if (unit != null)
				{
				}
			}
		}

		public override void OnEnter()
		{
			if (Me.IsTank())
			{
				Alert.Show(
					"Tanking Not Supported",
					string.Format(
						"Tanking is not supported in the {0} script. If you wish to stay in raid and play manually then press 'Continue'. Otherwise you will automatically leave raid.",
						Name),
					30,
					true,
					true,
					null,
					() => Lua.DoString("LeaveParty()"),
					"Continue",
					"Leave");
			}
			else
			{
				Alert.Show(
					"Do Not AFK",
					"It is highly recommended you do not afk while in a raid and be prepared to intervene if needed in the event something goes wrong or you're asked to perform a certain task.",
					20,
					true,
					false,
					null,
					null,
					"Ok");
			}	
		}

		#endregion

		#region Root Behavior

		LocalPlayer Me { get { return StyxWoW.Me; }}

		[EncounterHandler(0)]
		public Composite RootBehavior()
		{
			return new PrioritySelector();
		}

		#endregion

		#region Siegecrafter Blackfuse

		private const uint AutomatedShredderId = 71591;
		private const int DeathFromAboveMissileId = 147010;

		[EncounterHandler(71504, "Siegecrafter Blackfuse")]
		public Composite CreateBehavior_SiegecrafterBlackfuse()
		{
			WoWUnit boss = null;
			return new PrioritySelector(ctx => boss = (WoWUnit)ctx,
				new ActionRunCoroutine(() => SiegecrafterBlackfuse_MainLogic(boss)));
		}

		IEnumerator SiegecrafterBlackfuse_MainLogic(WoWUnit boss)
		{
			yield break;
		}

		#endregion

		#region Paragons of the Klaxxi

		[EncounterHandler(71504, "Siegecrafter Blackfuse")]
		public Composite CreateBehavior_ParagonsOfTheKlaxxi()
		{
			WoWUnit boss = null;
			return new PrioritySelector(ctx => boss = (WoWUnit)ctx,
				new ActionRunCoroutine(() => ParagonsOfTheKlaxxi_MainLogic(boss)));
		}

		IEnumerator ParagonsOfTheKlaxxi_MainLogic(WoWUnit boss)
		{
			yield break;
		}

		#endregion

		#region Garrosh Hellscream

		[EncounterHandler(71865, "Garrosh Hellscream")]
		public Composite CreateBehavior_GarroshHellscream()
		{
			WoWUnit boss = null;
			return new PrioritySelector(ctx => boss = (WoWUnit)ctx,
				new ActionRunCoroutine(() => GarroshHellscream_MainLogic(boss)));
		}

		IEnumerator GarroshHellscream_MainLogic(WoWUnit boss)
		{
			yield break;
		}

		#endregion
	}
	 */
}
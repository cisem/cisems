using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using Bots.DungeonBuddy.Enums;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Burning_Crusade
{
	public class MagistersTerrace : Dungeon
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 198; }
		}

		public override WoWPoint Entrance
		{
			get { return new WoWPoint(12882.49, -7341.705, 65.53025); }
		}

		public override WoWPoint ExitLocation
		{
			get { return new WoWPoint(-5.751736, 0.2760417, -0.2375327); }
		}

		#endregion

		[ObjectHandler(188173, "Use object to port outside")]
		public Composite PortOutsideFarmMode()
		{
			WoWGameObject obj = null;

			return new PrioritySelector(
				ctx => obj = ctx as WoWGameObject,
				new Decorator(
					ctx => DungeonBuddySettings.Instance.DungeonType == DungeonType.Farm && !ScriptHelpers.IsBossAlive("Kael'thas Sunstrider"),
					ScriptHelpers.CreateInteractWithObject(ctx => obj)));
		}
	}
}
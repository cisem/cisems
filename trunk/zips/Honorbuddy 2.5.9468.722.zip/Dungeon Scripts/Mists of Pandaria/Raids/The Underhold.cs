﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;
using System.Windows.Media;
using Bots.DungeonBuddy.Avoidance;
using Bots.DungeonBuddy.Behaviors;
using Bots.DungeonBuddy.Profiles.Handlers;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using AvoidanceManager = Bots.DungeonBuddy.Avoidance.AvoidanceManager;
using Vector2 = Tripper.Tools.Math.Vector2;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
	/* Not finsished
	public class TheUnderhold : Dungeon
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 724; }
		}

		public override WoWPoint Entrance
		{
			get { return new WoWPoint(1242.479, 600.5036, 318.0787); }
		}

		#region Movement

		public override MoveResult MoveTo(WoWPoint location)
		{
			var myLoc = Me.Location;

			return MoveResult.Failed;
		}

		#endregion

		public override void RemoveTargetsFilter(List<WoWObject> units)
		{
			units.RemoveAll(
				ret =>
				{
					var unit = ret.ToUnit();
					if (unit != null) { }
					return false;
				});
		}

		public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
		{
			foreach (var obj in incomingunits)
			{
				var unit = obj as WoWUnit;
				if (unit != null)
				{
					if (unit.Entry == IceTombId && unit.DistanceSqr < 40*40)
					{
						outgoingunits.Add(unit);
					}
				}
			}
		}

		public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
		{
			foreach (var priority in units)
			{
				var unit = priority.Object as WoWUnit;
				if (unit != null)
				{
					switch (unit.Entry)
					{
							// these do heals so need to be dealt with first
						case ZarthikAmberPriestId:
							// break out group members from the ice tomb
						case IceTombId:
							priority.Score += 5000;
							break;
					}
				}
			}
		}

		public override void OnEnter()
		{
			if (Me.IsTank())
			{
				Alert.Show(
					"Tanking Not Supported",
					string.Format(
						"Tanking is not supported in the {0} script. If you wish to stay in raid and play manually then press 'Continue'. Otherwise you will automatically leave raid.",
						Name),
					30,
					true,
					true,
					null,
					() => Lua.DoString("LeaveParty()"),
					"Continue",
					"Leave");
			}
			else
			{
				Alert.Show(
					"Do Not AFK",
					"It is highly recommended you do not afk while in a raid and be prepared to intervene if needed in the event something goes wrong or you're asked to perform a certain task.",
					20,
					true,
					false,
					null,
					null,
					"Ok");
			}
		}

		#endregion

		#region Root Behavior

		private LocalPlayer Me
		{
			get { return StyxWoW.Me; }
		}

		[EncounterHandler(0)]
		public Composite RootBehavior()
		{
			return new PrioritySelector();
		}

		#endregion

		#region Malkorok

		private const int BloodRageSpellId = 142879;
		private const int ArcingSmashSpellId = 143805;
		private const uint BreathOfYShaarjId = 142842;

		[EncounterHandler(71454, "Malkorok")]
		public Composite CreateBehavior_Malkorok()
		{
			var roomCenter = new WoWPoint(1914.795, -4950.756, -198.9773);
			WoWPoint rangeSpreadoutPoint = WoWPoint.Zero;
			const float roomRadius = 40;

			WaitTimer arcingSmashTimer = WaitTimer.FiveSeconds;
			WaitTimer breathOfYShaarjTimer = WaitTimer.FiveSeconds;
			var arcingSmashAngles = new List<ScriptHelpers.AngleSpan>();
			// ToDO: Fixed conal avoidance.
			// ToDO: Fix idle issue on healers.
			// run away from raid members if has the Displaced Energy debuf
			AddAvoidObject(ctx => Me.HasAura("Displaced Energy"), 15, o => !o.IsMe && o is WoWPlayer);

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// initialize the ranged stand at location during phase one.
				new Decorator(
					ctx => rangeSpreadoutPoint == WoWPoint.Zero && Me.IsRange(),
					new Action(
						ctx =>
						{
							rangeSpreadoutPoint = GetRandomPointAroundLocation(roomCenter, 0, 359, 20, roomRadius);
							return RunStatus.Failure;
						})),
				// Avoid the Arcing Smash ability
				new Decorator(
					ctx => boss.CastingSpellId == ArcingSmashSpellId,
					new PrioritySelector(
						new Decorator(
							ctx => arcingSmashTimer.IsFinished,
							new Action(
								ctx =>
								{
									arcingSmashAngles.Add(
										new ScriptHelpers.AngleSpan((int) WoWMathHelper.RadiansToDegrees(WoWMathHelper.NormalizeRadian(boss.Rotation)), 45));
									arcingSmashTimer.Reset();
									return RunStatus.Failure;
								})),
						ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => true, ctx => boss, new ScriptHelpers.AngleSpan(0, 45)))),
				// Avoid the Breath Of YShaarjId ability
				new Decorator(
					ctx => boss.CastingSpellId == BreathOfYShaarjId,
					new PrioritySelector(
						new Action(
							ctx =>
							{
								breathOfYShaarjTimer.Reset();
								return RunStatus.Failure;
							}),
						ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => true, ctx => boss, arcingSmashAngles.ToArray()))),
				// clear the arcingSmashAngles list after boss is done casting the Breath Of YShaarjId ability
				new Decorator(
					ctx => !breathOfYShaarjTimer.IsFinished && boss.CastingSpellId != BreathOfYShaarjId && arcingSmashAngles.Any(),
					new Action(ctx => arcingSmashAngles.Clear())),
				// Ranged phase 1 logic.
				new Decorator(
					ctx =>
						Me.IsRangeDps() && boss.CastingSpellId != BloodRageSpellId && !boss.HasAura(BloodRageSpellId)
						&& boss.CastingSpellId != ArcingSmashSpellId && boss.CastingSpellId != BreathOfYShaarjId
						&& !AvoidanceManager.IsRunningOutOfAvoid,
					new PrioritySelector(
						// move to my phase one location.
						new Decorator(
							ctx => Me.Location.DistanceSqr(rangeSpreadoutPoint) > 10*10,
							new Action(ctx => Navigator.MoveTo(rangeSpreadoutPoint)))
						)),
				// Phase 2 logic
				// Stack up on tank
				new Decorator(
					ctx => boss.CastingSpellId == BloodRageSpellId || !boss.HasAura(BloodRageSpellId),
					new PrioritySelector(
						ctx => ScriptHelpers.Tank,
						new Decorator<WoWPlayer>(
							player => Me.Location.DistanceSqr(player.Location) > 8*8,
							new Helpers.Action<WoWPlayer>(player => Navigator.MoveTo(player.Location)))))
				);
		}

		private WoWPoint GetRandomPointAroundLocation(WoWPoint point, int startAng, int endAng, float minDist, float maxDist)
		{
			if (endAng < startAng)
				endAng += 360;
			var randomRadians = WoWMathHelper.NormalizeRadian(
				WoWMathHelper.DegreesToRadians(ScriptHelpers.Rnd.Next(startAng, endAng)));
			var randomDist = ScriptHelpers.Rnd.Next((int) minDist, (int) maxDist);
			return point.RayCast(randomRadians, randomDist);
		}

		#endregion

		#region Spoils of Pandoria

		private const uint StoneStatueId = 72535;
		private const uint XiangLinId = 73725;
		private const uint JadeTempestSpellId = 148582;
		private const uint KunDaId = 71408;
		private const uint FractureSpellId = 148513;
		private const uint SetToBlowSpellId = 146365;
		private const uint EncapsulatedPheromonesSpellId = 145285;
		// todo. check out this ability
		private const uint MatterScrambleId = 145369;
		// todo. should probably stand in this.
		private const uint CrimsonReconstitutionSpellId = 145270;
		private const uint MoguRuneOfPowerSpellId = 145460;
		private const int ForbiddenMagicId = 145230;
		private const uint ZarthikAmberPriestId = 71397;
		private const uint WindstormSpellId = 145286;
		private const int HardenFleshSpelId = 144922;
		private const int EarthenShardSpellId = 144923;
		private const uint SparkOfLifeId = 71433;
		private const uint GustingBombSpellId = 145714;
		private const uint ThrowExplosivesMissileId = 145702;
		// this spell needs to be casted when player has 'Set to Blow' aura
		private const int ThrowBombSpellId = 146364;

		private static readonly Vector2 SopSouthQuadrantCorner = new Vector2(1513.785f, -5093.607f);
		private static readonly Vector2 SopNorthQuadrantCorner = new Vector2(1748.122f, -5155.105f);
		private static readonly Vector2 SopWestQuadrantCorner = new Vector2(1646.395f, -5004.169f);
		private static readonly Vector2 SopEastQuadrantCorner = new Vector2(1617.165f, -5246.308f);
		private static readonly Vector2 SopSouthWestMidPoint = new Vector2(1580.09f, -5048.888f);
		private static readonly Vector2 SopNorthWestMidPoint = new Vector2(1697.259f, -5079.637f);
		private static readonly Vector2 SopNorthEastMidPoint = new Vector2(1682.644f, -5200.707f);
		private static readonly Vector2 SopSouthEastMidPoint = new Vector2(1565.475f, -5169.958f);
		private static readonly Vector2 SopCenterPoint = new Vector2(1631.367f, -5124.798f);

		private readonly DungeonArea _eastQuadrantArea = new DungeonArea(
			SopSouthEastMidPoint,
			SopCenterPoint,
			SopNorthEastMidPoint,
			SopEastQuadrantCorner);

		private readonly DungeonArea _northQuadrantArea = new DungeonArea(
			SopCenterPoint,
			SopNorthWestMidPoint,
			SopNorthQuadrantCorner,
			SopNorthEastMidPoint);

		private readonly DungeonArea _southQuadrantArea = new DungeonArea(
			SopSouthQuadrantCorner,
			SopSouthWestMidPoint,
			SopCenterPoint,
			SopSouthEastMidPoint);

		private WoWPlayer _spoilsOfPandoriaLeader;

		private readonly DungeonArea _westQuadrantArea = new DungeonArea(
			SopSouthWestMidPoint,
			SopWestQuadrantCorner,
			SopNorthWestMidPoint,
			SopCenterPoint);

		private PosQuadrant GetQuadrantAtLocation(WoWPoint point)
		{
			if (point.Z > -280 || point.Z < -295)
				return PosQuadrant.None;

			if (_southQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.South;

			if (_westQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.West;

			if (_northQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.North;

			if (_eastQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.East;

			return PosQuadrant.None;
		}

		// Todo: get data for Pardaren Relics

		// ToDo. figure out the name of the Stone Statue frontal cone ability

		[EncounterHandler(72281, "Spoils of Pandoria", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
		public Composite CreateBehavior_SpoilsOfPandoria()
		{
			// todo figure out the radius of this attack
			AddAvoidObject(ctx => true, 10, o => o.Entry == XiangLinId && o.ToUnit().CastingSpellId == JadeTempestSpellId);

			// toDo figure out the radius of this attack and if it's circular or conal
			AddAvoidObject(ctx => true, 10, o => o.Entry == KunDaId && o.ToUnit().CastingSpellId == FractureSpellId);

			// run away from raid members so they don't die with me.. ToDo. figure out how to throw the bombs.
			//
			AddAvoidObject(ctx => Me.HasAura("Set to Blow"), 20, o => !o.IsMe && o is WoWPlayer);


			AddAvoidObject(ctx => true, 4, SparkOfLifeId);

			AddAvoidObject(ctx => true, 4, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == EncapsulatedPheromonesSpellId);

			// ToDo. figure out the trails these things leave
			AddAvoidObject(ctx => true, 3, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == GustingBombSpellId);

			AddAvoidObject(ctx => true, 5, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == WindstormSpellId);

			AddAvoidLocation(
				ctx => true,
				2,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == ThrowExplosivesMissileId));

			return new PrioritySelector(
				ctx =>
				{
					if (_spoilsOfPandoriaLeader == null || !_spoilsOfPandoriaLeader.IsValid)
						_spoilsOfPandoriaLeader = GetSpoilsOfPandoiaLeader();
					return _spoilsOfPandoriaLeader;
				},
				new Decorator(ctx => ScriptHelpers.IsBossAlive("Spoils of Pandoria"),
					new PrioritySelector(
						// ToDo. figure out how to throw the bombs. WIP
						new Decorator(
							ctx => Me.HasAura("Set to Blow"),
							new PrioritySelector(
						
								)),
						new PrioritySelector(
							ctx => Me.CurrentTarget,
							new Decorator(
								ctx => ctx != null,
								new PrioritySelector(
									ScriptHelpers.CreateInterruptCast(ctx => (WoWUnit) ctx, HardenFleshSpelId, EarthenShardSpellId),
									// dispell Residue (a HOT) from current target if exists.
									ScriptHelpers.CreateDispellEnemy("Residue", ScriptHelpers.EnemyDispellType.Magic, ctx => (WoWUnit) ctx),
									// dispell Rage of the Empress (damage buff) from current target if exists.
									ScriptHelpers.CreateDispellEnemy("Rage of the Empress", ScriptHelpers.EnemyDispellType.Magic, ctx => (WoWUnit) ctx),
									ScriptHelpers.CreateDispellEnemy("Enrage", ScriptHelpers.EnemyDispellType.Enrage, ctx => (WoWUnit) ctx)
									))),
						// move to a nearby rune for the benefits
						new PrioritySelector(
							ctx => GetNearbyRuneOfPower(),
							new Decorator<WoWAreaTrigger>(
								a => a.DistanceSqr > 3*3,
								new Helpers.Action<WoWAreaTrigger>(a => Navigator.MoveTo(a.Location))))))
				);
		}

		[EncounterHandler(71393, "Mogu Shadow Ritualist")]
		public Composite CreateBehavior_MoguShadowRitualist()
		{
			// todo figure out the radius of this attack
			AddAvoidObject(ctx => true, 10, o => o.Entry == XiangLinId && o.ToUnit().CastingSpellId == JadeTempestSpellId);

			// toDo figure out the radius of this attack and if it's circular or conal
			AddAvoidObject(ctx => true, 10, o => o.Entry == KunDaId && o.ToUnit().CastingSpellId == FractureSpellId);

			// run away from raid members so they don't die with me.. ToDo. figure out how to throw the bombs.
			AddAvoidObject(ctx => Me.HasAura("Set to Blow"), 20, o => !o.IsMe && o is WoWPlayer);

			// ToDo. Need the radius for these.
			AddAvoidObject(ctx => true, 5, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == EncapsulatedPheromonesSpellId);

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// ToDo. figure out how to throw the bombs. WIP
				new Decorator(
					ctx => Me.HasAura("Set to Blow"),
					new PrioritySelector(
						
						)),
				// move to a nearby rune for the benefits
				new PrioritySelector(
					ctx => GetNearbyRuneOfPower(),
					new Decorator<WoWAreaTrigger>(
						a => a.DistanceSqr > 3*3,
						new Helpers.Action<WoWAreaTrigger>(a => Navigator.MoveTo(a.Location)))),
				// interrupt Forbidden Magic cast
				ScriptHelpers.CreateInterruptCast(ctx => boss, ForbiddenMagicId)
				);
		}


		private WoWAreaTrigger GetNearbyRuneOfPower()
		{
			return ObjectManager.GetObjectsOfTypeFast<WoWAreaTrigger>()
				.Where(a => a.SpellId == MoguRuneOfPowerSpellId)
				.OrderBy(a => a.DistanceSqr)
				.FirstOrDefault(
					a =>
					{
						var myTarget = Me.IsHealer ? HealTargeting.Instance.FirstUnit : Targeting.Instance.FirstUnit;
						if (myTarget == null)
							return false;
						var maxRange = Me.IsMeleeDps() ? myTarget.MeleeRange() : 35;
						var pos = a.Location;
						if (Me.Location.Distance(pos) > maxRange)
							return false;
						pos.Z += 1;
						return GameWorld.IsInLineOfSpellSight(pos, myTarget.GetTraceLinePos());
					});
		}

		private WoWPlayer GetSpoilsOfPandoiaLeader()
		{
			var tanks = ScriptHelpers.GroupMembers.Where(g => g.IsTank).Select(p => p.Player).ToArray();
			// wait for one of the tanks to drop down into gauntlet before deciding which to follow.
			if (tanks.All(t => GetQuadrantAtLocation(t.Location) == PosQuadrant.None))
				return null;
			var partyLocs = Me.PartyMembers.Select(p => p.Location).ToList();
			if (!partyLocs.Any())
				partyLocs.Add(Me.Location);
			// return the tank that my party members are nearest to
			return tanks.OrderBy(t => partyLocs.Sum(p => p.Distance(t.Location)/partyLocs.Count)).FirstOrDefault();
		}

		private enum PosQuadrant
		{
			None,
			North,
			East,
			South,
			West
		}

		#endregion

		#region Thok the Bloodthirsty

		private const uint ThokTheBloodthirstyId = 71529;
		private const int FixateSpellId = 143445;
		private const int IceTombId = 71720;
		private const uint BurningBloodSpellId = 143783;

		[EncounterHandler(71529, "Thok the Bloodthirsty")]
		public Composite CreateBehavior_ThokTheBloodthirsty()
		{
			var roomCenter = new WoWPoint(1204.029, -5113.106, -289.3376);
			const float roomRadius = 79;

			// run from Thok when fixated or while he's picking a new target.
			AddAvoidObject(
				ctx => Me.HasAura(FixateSpellId),
				() => roomCenter,
				roomRadius - 5,
				40,
				o => o.Entry == ThokTheBloodthirstyId &&  (o.ToUnit().CastingSpellId == FixateSpellId || Me.HasAura(FixateSpellId)));

			// avoid Thok's front area
			AddAvoidObject(
				ctx => true,
				() => roomCenter,
				roomRadius - 5,
				20,
				o => o.Entry == ThokTheBloodthirstyId && o.ToUnit().IsAlive,
				o =>WoWMathHelper.CalculatePointInFront(o.Location, o.Rotation, 20));
			// avoid Thok's back side
			AddAvoidObject(
				ctx => true,
				() => roomCenter,
				roomRadius - 5,
				20,
				o => o.Entry == ThokTheBloodthirstyId && o.ToUnit().IsAlive,
				o => WoWMathHelper.CalculatePointBehind(o.Location, o.Rotation, 20));

			// avoid the fire on ground.
			AddAvoidObject(
				ctx => true,
				2,
				o =>
				{
					var areaTrigger = o as WoWAreaTrigger;
					return areaTrigger != null && areaTrigger.SpellId == BurningBloodSpellId;
				});

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// ranged classes should no wander too far from raid. (not a problem for melee)
				new Decorator(
					ctx => Me.IsRange() && !boss.HasAura("Blood Frenzy"),
					new PrioritySelector(
						ctx => GetRangedGroupCenter(),
						new Decorator<WoWPoint>(
							raidPos => Me.Location.DistanceSqr(raidPos) > 17*17,
							new Helpers.Action<WoWPoint>(raidPos => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(raidPos))))))
				);
		}

		private WoWPoint _rangedGroupCenter;
		private readonly WaitTimer _updateRangedGroupCenterPos = WaitTimer.FiveSeconds;

		private WoWPoint GetRangedGroupCenter()
		{
			if (_rangedGroupCenter == WoWPoint.Zero || _updateRangedGroupCenterPos.IsFinished)
			{
				_rangedGroupCenter = ScriptHelpers.GetGroupCenterLocation(g => g.IsRange, 20);
				_updateRangedGroupCenterPos.Reset();
			}
			return _rangedGroupCenter;
		}
		#endregion
		
	}
	 */
}
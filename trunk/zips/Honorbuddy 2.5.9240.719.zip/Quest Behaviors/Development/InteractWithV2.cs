﻿// Behavior originally contributed by Nesox / completely reworked by Chinajade
//
// LICENSE:
// This work is licensed under the
//     Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
// also known as CC-BY-NC-SA.  To view a copy of this license, visit
//      http://creativecommons.org/licenses/by-nc-sa/3.0/
// or send a letter to
//      Creative Commons // 171 Second Street, Suite 300 // San Francisco, California, 94105, USA.
//

#region Summary and Documentation

// DOCUMENTATION:
//     http://www.thebuddyforum.com/mediawiki/index.php?title=Honorbuddy_Custom_Behavior:_InteractWith
//
//
// QUICK DOX:
// INTERACTWITH interacts with mobs or objects in various fashions, including:
//  * Gossiping with the mob through a set of dialogs
//  * "Right-clicking" on the mob to complete a goal
//  * Buying particular items off of vendors
//  * Using an item on a mob or object.  The item can be one-click use, or two-click
//      use (two-click: clicks once to get a 'placement cursor', and clicks the
//      second time to drop the placement cursor on the mob or object).
//  * Looting or harvesting (through interaction) an item off a mob or object
// The behavior initiates interaction by "right clicking" on the mob of interest.
// The subsequent actions taken by the behavior depend on the attributes provided.
//
// BEHAVIOR ATTRIBUTES:
// *** ALSO see the documentation in QuestBehaviorBase.cs.  All of the attributes it provides
// *** are available here, also.  The documentation on the attributes QuestBehaviorBase provides
// *** is _not_ repeated here, to prevent documentation inconsistencies.
//
// Basic Attributes:
//      FactionIdN [at least one is REQUIRED: FactionIdN, MobIdN, MobIdIncludesSelf]
//          Identifies the faction of the mobs on which the interaction should take place.
//          If you specify both MobIdN and FactionIdN, the two sets will be combined,
//          and any target that fulfillseither MobIdN or FactionIdN will be selected for interaction.
//      MobIdN [at least one is REQUIRED: FactionIdN, MobIdN, MobIdIncludesSelf]
//          Identifies the mobs on which the interaction should take place.
//          The MobIdN can represent either an NPC (WoWUnit) or an Object (WoWObject).
//          The two types can freely be mixed.
//          If you specify both MobIdN and FactionIdN, the two sets will be combined,
//          and any target that fulfillseither MobIdN or FactionIdN will be selected for interaction.
//      MobIdIncludesSelf [Default: false; at least one is REQUIRED: FactionIdN, MobIdN, MobIdIncludesSelf]
//          Indentifies 'self' as one of the mobs on which the interaction should take place.
//          If you specify other qualifiers, such as required auras, missing auras, mob state,
//          not moving, etc, 'self' must meet the qualifers just like any other mob.
//      NumOfTimes [optional; Default: 1]
//          This is the number of times the behavior should interact with MobIdN.
//          Once this value is achieved, the behavior considers itself done.
//          If the Quest or QuestObjectiveIndex completes prior to reaching this
//          count, the behavior also terminates.
//
// Optional Target Qualifiers (applies to all targets, including 'self'):
// These attributes further qualify a target that fullfills the MobIdN/FactionIdN/Self selection.
//      AuraIdOnMobN [optional; Default: none]
//          The target *must* possess an aura that matches one of the defined 
//          AuraIdMissingFromMobN, in order to be considered a target for interaction.
//      AuraIdMissingFromMob [optional; Default: none]
//          The target must *not* possess an aura that matches one of the defined 
//          AuraIdMissingFromMobN, in order to be considered a target for interaction.
//      MobHpPercentLeft [optional; Default: 100.0]
//          The target's health must be at or below this value to be considered a qualfiied target.
//          This value is only considered if MobState is "BelowHp".
//      MobState [optional; Default: DontCare]
//          [Allowed values for NPC targets: Alive, AliveNotInCombat, BelowHp, Dead, DontCare]
//          This attribute qualifies the state the MobIdN or FactionIdN must be in,
//          when selecting targets for interaction.
//      NotMoving [optional; Default: false]
//          If true, the behavior will only consider targets that are not moving.
//
// Interaction by Buying Items:
//      BuyItemCount [optional; Default: 1]
//          This is the number of items (specified by BuyItemId) that should be
//          purchased from the Vendor (specified by MobId).
//      InteractByBuyingItemId [optional; Default: none]
//          This is the ItemId of the item that should be purchased from the
//          Vendor (specified by MobId).
//
// Interact by Casting Spell:
//      InteractByCastingSpellId [optional; Default: none]
//          Specifies an SpellId to use on the specified target.
//          The spell may be a normal 'one-click-to-use' spell, or it may be
//          a (two-click) spell that needs to be placed on the ground at
//          the target's location.
//
// Interaction by Gossiping:
//      InteractByGossipOptions [optional; Default: none]
//          Defines a comma-separated list of (1-based) numbers that specifies
//          which Gossip option to select in each dialog frame when chatting with an NPC.
//          This value should be separated with commas. ie. InteractByGossipOptions="1,1,4,2".
//
// Interaction by Looting:
//      InteractByLooting [optional; Default: false]
//          If true, the behavior will pick up loot from any loot frame
//          offered by the MobIdN.
//          This feature is largely unused since the WoW game mechanics
//          have changed.
//
// Interaction by Quest frames:
//      InteractByQuestFrameDisposition [optional; Default: TerminateProfile]
//          [Allowed values: Accept/Complete/Continue/Ignore/TerminateBehavior/TerminateProfile]
//          This attribute determines the behavior's response should the NPC
//          with which we've interacted offer us a quest frame.
//          Accept/Complete/Continue
//              clicks on the appropriate button in the offered quest frame.
//              The behavior continues after the appropriate button is clicked.
//          Ignore
//              closes the offered quest frame, and continues with the behavior.
//          TerminateBehavior
//              closes the offered quest frame, and terminates the behavior.
//              This is useful in situations where the Quest frame was unexpected,
//              but tells us what 'state' an NPC may be in.  See the "By Any Means Necessary"
//              in the Examples section below.
//
// Interact by Using Item:
//      InteractByUsingItemId [optional; Default: none]
//          Specifies an ItemId to use on the specified MobInN.
//          The item may be a normal 'one-click-to-use' item, or it may be
//          a (two-click) item that needs to be placed on the ground at
//          the MobIdN's location.
//
// Tunables:
//      CollectionDistance [optional; Default: 100.0]
//          Measured from the toon's current location, this value specifies
//          the maximum distance that should be searched when looking for
//          a viable MobId with which to interact.
//      IgnoreCombat [optional; Default: false]
//          If true, this behavior will not defend itself if attacked, and
//          will carry on with its main task.
//      IgnoreLoSToTarget [optional; Default: false]
//          If true, the behavior will not consider Line of Sight when trying to interact
//          with the selected target.
//      InteractBlacklistTimeInSeconds [optional: Default: 180]
//          Specifies the number of seconds for which a target with which we've interacted
//          is to remain blacklisted.
//      KeepTargetSelected [optional; Default: false]
//          If true, the behavior will not clear the toon's target after the interaction
//          is complete.  Instead, the target will remain on the last interacted
//          mob until a new mob is ready for interaction.
//          If false, the behavior clears the toon's target immediately after
//          it considers the interaction complete.
//      MinRange [optional; Default: 0.0]
//          Defines the minimum range at which the interaction with MobIdN should take place.
//          If the toon is too close to the mob, the toon will move to acquire this minimum
//          distance to the mob.
//      PreInteractMountStrategy [optional; Default: None]
//          [allowed values: CancelShapeshift, Dismount, DismountOrCancelShapeshift, Mount, None]
//          Provides the opportunity to alter the mounting state of a toon immediately prior
//          to interacting, or using an object.  The options are defined as follows:
//              CancelShapeshift
//                  Cancels *any* shapeshifted form, whether it represents a 'mounted form'
//                  or not.  Examples of non-mounted forms include a Druid's Bear or Cat Form.
//              Dismount
//                  Unmounts from an explicit mount, or cancels a 'mounted form'.  Examples
//                  of mounted forms are Druid Flight Forms, Druid Travel Form, Shaman Ghost Wolf,
//                  and Worgen Running Wild.
//              DismountOrCancelShapeshift
//                  Dismounts or cancel's a shapeshifted form--whichever is appropriate.
//              Mount
//                  Mounts the mount defined in the user's preference settings.
//              None
//                  Does not alter the existing mounting state prior to interaction.
//      ProactiveCombatStrategy [optional; Default: ClearAll]
//          [allowed values: NoClear/ClearMobsTargetingUs/ClearMobsThatWillAggro/ClearAll]
//              NoClear
//                  Will not proactively clear around the selected target.  This means that
//                  an attempt to interact with the target could be interrupted by a mob.
//              ClearMobsTargetingUs
//                  If a mob targets us we immediately move to engage it, rather than wait
//                  for the mob to actually close the range to us, put us in combat, then
//                  we deal with it.  This option prevents dragging a large number of mobs
//                  to our selected interact target only to have to fight them.
//              ClearMobsThatWillAggro
//                  If mobs within 'aggro range' of our selected interact target are cleared
//                  before we attempt to interact with the selected target.  This prevents us
//                  from being interrupted when we attempt to interact with our selected target.
//              ClearAll
//                  Combines ClearMobsThatWillAggro and ClearMobsTargetingUs.
//      Range [optional; Default: interaction range defined by the object with which we're trying to interact]
//          Defines the maximum range at which the interaction with MobIdN should take place.
//          If the toon is out of range, the toon will be moved within this distance
//          of the mob.
//          It is highly recommended you let this attribute default, unless there is
//          a compelling reason not to.
//      WaitForNpcs [optional; Default: true]
//          This value affects what happens if there are no MobIds in the immediate area.
//          If true, the behavior will move to the next hunting ground waypoint, or if there
//          is only one waypoint, the behavior will stand and wait for MobIdN to respawn.
//          If false, and the behavior cannot locate MobIdN in the immediate area, the behavior
//          considers itself complete.
//          Please see "Things to know", below.
//      WaitTime [optional; Default: 0ms]
//          Defines the number of milliseconds to wait after the interaction is successfully
//          conducted before carrying on with the behavior on other mobs.
//      X/Y/Z [optional; Default: toon's current location when behavior is started]
//          This specifies the location where the toon should loiter
//          while waiting to interact with MobIdN.  If you need a large hunting ground
//          you should prefer using the <HuntingGrounds> sub-element, as it allows for
//          multiple locations (waypoints) to visit.
//          This value is automatically converted to a <HuntingGrounds> waypoint.
//
// BEHAVIOR EXTENSION ELEMENTS (goes between <CustomBehavior ...> and </CustomBehavior> tags)
// See the "Examples" section for typical usage.
//      HuntingGrounds [optional; Default: none]
//          The HuntingGrounds contains a set of Waypoints we will visit to seek mobs
//          that fulfill the quest goal.  The <HuntingGrounds> element accepts the following
//          attributes:
//              WaypointVisitStrategy= [optional; Default: Random]
//              [Allowed values: InOrder, PickOneAtRandom, Random]
//              Determines the strategy that should be employed to visit each waypoint.
//              Any mobs encountered while traveling between waypoints will be considered
//              viable.  The Random strategy is highly recommended unless there is a compelling
//              reason to otherwise.  The Random strategy 'spread the toons out', if
//              multiple bos are running the same quest.
//              The PickOneAtRandom strategy will only visit one waypoint on the list
//              and camp the mobs from the single selected waypoint.  This is another good tactic
//              for spreading toons out in heavily populated areas.
//          Each Waypoint is provided by a <Hotspot ... /> element with the following
//          attributes:
//              Name [optional; Default: X/Y/Z location of the waypoint]
//                  The name of the waypoint is presented to the user as it is visited.
//                  This can be useful for debugging purposes, and for making minor adjustments
//                  (you know which waypoint to be fiddling with).
//              X/Y/Z [REQUIRED; Default: none]
//                  The world coordinates of the waypoint.
//              Radius [optional; Default: 10.0]
//                  Once the toon gets within Radius of the waypoint, the next waypoint
//                  will be sought.
//
// THiNGS TO KNOW:
// * As a design choice, this behavior waits a variant amount of time when 'clicking on things'.
//      We try to simulate an attentive human as much as possible.
//
// * The InteractByGossipOptions and InteractByBuyingItemId attributes can be combined to get to
//      Innkeeper goods.  Innkeepers require you to select one of their gossip options before they
//      will show you their wares for sale.
//
// * If the InteractByGossipOptions selects a "bind to this location" option, then InteractWith
//      will automatically confirm the request to bind at the location.  After the binding is complete
//      InteractWith displays a confirmation message of the new bind location.
//
// * If you specify MobState="Dead", but only alive mobs exist in the area, InteractWith
//      will kill the alive mobs, and then try to interact with them once they are dead.
//
// * The behavior pro-actively clears mobs within aggro range of the selected interact target.
//      This prevents the mobs from interfering with the interaction.  If IgnoreCombat="true",
//      then this pro-active clearing is also turned off.
//
// * If you are trying to gossip with NPCs that are in combat, this behavior will help the NPC
//      kill the mob so the NPC will leave combat.  This is necessary because many NPCs will not
//      gossip when they are in combat.
//
// * Be careful when specifying the WaitForNpcs="false".
//      The 'interact blacklist' is internal to the behavior.  The means the blacklist is destroyed
//      any time the behavior exits, and a fresh one is created upon re-entry to the behavior.
//      This means InteractWith does not know which mobs have already been interacted and which
//      have not, when WaitForNpcs="true".  The can cause slow progress as the failure detection
//      mechnaisms built into the behavior kick in and re-exclude non-viable mobs as they are
//      rediscovered.
//
// * Deprecated attributes:
//      + BuySlot
//          This attribute is deprecated, and BuySlot presents a number of problems.
//          If a vendor presents 'seasonal' or limited-quantity wares, the slot number
//          for the desired item can change.
//          OLD DOX: Buys the item from the slot. Slots are:    0 1
//                                                              2 3
//                                                              4 5
//                                                              6 7
//                                                              page2
//                                                              8 9 etc.
//      + ObjectType
//          This option should no longer be specified--the behavior just 'figures it out'
//      + Nav--prefer MovementBy, instead.
//          For support reasons, here is the old documentation:
//              Nav [optional; Default: not any]
//              [Allowed values: CTM, Mesh, None]
//              This attribute is no longer used--use MovementBy, instead.
//              (See documentation in QuestBehaviorBase for details).
//

#endregion

#region Examples

// BUYING AN ITEM:
// From a simple vendor that immediately presents you with a frame of their wares:
//      <CustomBehavior File="InteractWith" MobId="44236" InteractByBuyingItemId="2723"
//			X="-8365.76" Y="594.658" Z="97.00068" />
//
// From an Innkeeper that requires you to gossip before showing you their wares.
// Gossip entry 2 is the "Let me browse your goods." option from Thaegra Tillstone.  (The InteractBy* options
// are not order dependent.)
//      <CustomBehavior File="InteractWith" MobId="44235" InteractByGossipOptions="2" InteractByBuyingItemId="4540"
//			X="-8365.76" Y="594.658" Z="97.00068" />
//
//
// BINDING AT AN INN:
// Gossip entry 1 is the "Make this inn your home." option in Thaegra Tillstone's Inn in the Stormwind
// Dwarven District:
//      <If Condition="Me.HearthstoneAreaId != 5150">
//          <CustomBehavior File="InteractWith" MobId="44235" InteractByGossipOptions="1" />
//		        X="-8365.76" Y="594.658" Z="97.00068" />
//      </If>
// The only way to obtain the "area id" for the Condition is to actually set your hearthstone,
// then use the following command with HBConsole (or Developer Tools):
//      Logging.Write("AreaID: {0}", StyxWoW.Me.HearthstoneAreaId);
//
//
// QUEST EXAMPLES:  
// "By Any Means Necessary" (http://wowhead.com/quest=9978)
// This is a difficult quest for a number of reasons. First, a bug in the WoWclient indicates the quest
// is always completed, whether it is or not.  Thus we can not use an "IsCompleted" test to make decisions.
// Because of this bug, we cannot associate a QuestId attribute with our invocation of InteractWith.
// Second, Empoor may be in one of two states.  In one state, he'll offer us a gossip frame, and we must gossip
// and finish the ensuing fight before we can turn in the quest.  In the other state, he allows us to turn in
// the quest immediately (this happens when someone else has just fought him, and he stays in the second state
// for a while).
// To solve the problem, we arrange for InteractWith to gossip with the NPC.  If he offers the Quest frame,
// we terminate the 'gossip' behavior (via providing the InteractByQuestFrameDisposition="TerminateBehavior"
// attribute.
//      <!-- A couple of states for Empoor:
//      	1. We may need to gossip, do the fight, then turn in quest
//  	   	2. Someone else may have started and finished the fight already, and we can
//      		turn in quest immediately.
//      	NB: The WoWclient makes this quest appears complete, even though its not.
//      	So, we can't use the "IsQuestCompleted()" qualifier as a valid check.
//      	-->
//      <CustomBehavior File="InteractWith" MobId="18482" GossipOptions="1"
//      	InteractByQuestFrameDisposition="TerminateBehavior" >
//      	<HuntingGrounds>
//      		<Hotspot Name="Tuurem" X="-2037.871" Y="4377.199" Z="1.805441" />
//      		<Hotspot Name="Shattrath upper ring" X="-1955.325" Y="5029.867" Z="31.30444" />
//      		<Hotspot Name="Shattrath tunnel entrance" X="-1548.137" Y="5079.232" Z="-17.91318" />
//      	</HuntingGrounds>
//      </CustomBehavior>
//      <TurnIn QuestName="By Any Means Necessary" QuestId="9978" TurnInName="Empoor" TurnInId="18482" />
//
// "Fear No Evil" (http://wowhead.com/quest=28809)
// Revive four injured soldiers (by interacting with them) using Paxton's Prayer Book (http://wowhead.com/item=65733).
//      <CustomBehavior File="InteractWith" QuestId="28809" MobId="50047" NumOfTimes="4"
//          CollectionDistance="1" >
//          <HuntingGrounds WaypointVisitStrategy="Random" >
//              <Hotspot Name="Eastern Tent and Campfire" X="-8789.213" Y="-253.3615" Z="82.46034" />
//              <Hotspot Name="North Campfire" X="-8757.012" Y="-188.6659" Z="85.05094" />
//              <Hotspot Name="Mine entrance" X="-8716.521" Y="-105.2505" Z="87.57959" />
//              <Hotspot Name="NW LeanTo and Campfire" X="-8770.273" Y="-111.1501" Z="84.09385" />
//          </HuntingGrounds>
//      </CustomBehavior>
//

#endregion

#region Usings

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Controls.Primitives;
using System.Xml.Linq;
using Buddy.Coroutines;
using CommonBehaviors.Actions;
using Honorbuddy.QuestBehaviorCore;
using Honorbuddy.QuestBehaviorCore.XmlElements;
using JetBrains.Annotations;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.CommonBot.Profiles;
using Styx.Helpers;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.CommonBot.Coroutines;
using Action = Styx.TreeSharp.Action;

#endregion

namespace Honorbuddy.Quest_Behaviors.InteractWith
{
	// DO NOT USE THIS BECAUSE IT"S UNDER DEVELOPMENT AND WILL BE MOVED IN THE FUTURE!1!1!!1!
	[CustomBehaviorFileName(@"InteractWithV2")]
	public class InteractWithV2 : QuestBehaviorBase
	{
		#region Constructor and argument processing

		public InteractWithV2(Dictionary<string, string> args)
			: base(args)
		{
			try
			{
				// NB: Core attributes are parsed by QuestBehaviorBase parent (e.g., QuestId, NonCompeteDistance, etc)

				// Primary attributes...
				MobIds = GetAttributeAsArray<int>("MobIds", false, ConstrainAs.MobId, new[] {"NpcIds"}, null);

				if (MobIds != null && MobIds.Count() == 0)
					MobIds = GetNumberedAttributesAsArray<int>("MobId", 0, ConstrainAs.MobId, new[] {"NpcId"});
				MobIdIncludesSelf = GetAttributeAsNullable<bool>("MobIdIncludesSelf", false, null, null) ?? false;
				FactionIds = GetNumberedAttributesAsArray<int>("FactionId", 0, ConstrainAs.MobId, null);
				NumOfTimes = GetAttributeAsNullable<int>("NumOfTimes", false, ConstrainAs.RepeatCount, null) ?? 1;

				// Additional target qualifiers...
				AuraIdsOnMob = GetNumberedAttributesAsArray<int>("AuraIdOnMob", 0, ConstrainAs.AuraId, null);
				AuraIdsMissingFromMob = GetNumberedAttributesAsArray<int>("AuraIdMissingFromMob", 0, ConstrainAs.AuraId, null);
				MobState = GetAttributeAsNullable<MobStateType>("MobState", false, null, new[] {"NpcState"}) ?? MobStateType.DontCare;
				NotMoving = GetAttributeAsNullable<bool>("NotMoving", false, null, null) ?? false;

				// InteractionBy attributes...
				InteractByBuyingItemId = GetAttributeAsNullable("InteractByBuyingItemId", false, ConstrainAs.ItemId, null)
										?? GetAttributeAsNullable<int>("BuyItemId", false, ConstrainAs.ItemId, null) /*Legacy name--don't use */
										?? 0;
				InteractByCastingSpellId = GetAttributeAsNullable("InteractByCastingSpellId", false, ConstrainAs.SpellId, null) ?? 0;
				InteractByGossipOptions = GetAttributeAsArray<int>(
					"InteractByGossipOptions",
					false,
					new ConstrainTo.Domain<int>(-1, 10),
					null,
					null);
				if (InteractByGossipOptions.Length <= 0)
				{
					InteractByGossipOptions = GetAttributeAsArray<int>(
						"GossipOptions",
						false,
						new ConstrainTo.Domain<int>(-1, 10),
						new[] {"GossipOption"},
						null);
				} /*Legacy name--don't use */
				InteractByLooting = GetAttributeAsNullable<bool>("InteractByLooting", false, null, null)
									?? GetAttributeAsNullable<bool>("Loot", false, null, null) /* Legacy name--don't use*/
									?? false;
				InteractByQuestFrameAction = GetAttributeAsNullable<QuestFrameDisposition>(
					"InteractByQuestFrameDisposition",
					false,
					null,
					null)
											?? QuestFrameDisposition.TerminateProfile;
				InteractByUsingItemId = GetAttributeAsNullable<int>("InteractByUsingItemId", false, ConstrainAs.ItemId, null) ?? 0;

				// Tunables...
				BuyItemCount = GetAttributeAsNullable<int>("BuyItemCount", false, ConstrainAs.CollectionCount, null) ?? 1;
				CollectionDistance = GetAttributeAsNullable<double>("CollectionDistance", false, ConstrainAs.Range, null) ?? 100;
				HuntingGroundCenter = GetAttributeAsNullable<WoWPoint>("", false, ConstrainAs.WoWPointNonEmpty, null) ?? Me.Location;
				IgnoreCombat = GetAttributeAsNullable<bool>("IgnoreCombat", false, null, null) ?? false;
				IgnoreLoSToTarget = GetAttributeAsNullable<bool>("IgnoreLoSToTarget", false, null, null) ?? false;
				InteractBlacklistTimeInSeconds =
					GetAttributeAsNullable<int>("InteractBlacklistTimeInSeconds", false, ConstrainAs.CollectionCount, null) ?? 180;
				KeepTargetSelected = GetAttributeAsNullable<bool>("KeepTargetSelected", false, null, null) ?? false;
				MobHpPercentLeft =
					GetAttributeAsNullable<double>("MobHpPercentLeft", false, ConstrainAs.Percent, new[] {"HpLeftAmount"}) ?? 100.0;
				PreInteractMountStrategy = GetAttributeAsNullable<MountStrategyType>("PreInteractMountStrategy", false, null, null)
											?? MountStrategyType.None;
				ProactiveCombatStrategy = GetAttributeAsNullable<ProactiveCombatStrategyType>(
					"ProactiveCombatStrategy",
					false,
					null,
					null)
										?? ProactiveCombatStrategyType.ClearAll;
				RangeMax = GetAttributeAsNullable<double>("Range", false, ConstrainAs.Range, null);
				RangeMin = GetAttributeAsNullable<double>("MinRange", false, ConstrainAs.Range, null);
				WaitForNpcs = GetAttributeAsNullable<bool>("WaitForNpcs", false, null, null) ?? true;
				WaitTime = GetAttributeAsNullable<int>("WaitTime", false, ConstrainAs.Milliseconds, null) ?? 0;

				// Deprecated attributes...
				InteractByBuyingItemInSlotNum =
					GetAttributeAsNullable<int>(
						"InteractByBuyingItemInSlotNum",
						false,
						new ConstrainTo.Domain<int>(-1, 100),
						new[] {"BuySlot"}) ?? -1;
				GetAttributeAsNullable<Deprecated_MobType>("ObjectType", false, null, new[] {"MobType"}); // Deprecated--no longer used
				var navigationMode = GetAttributeAsNullable<NavigationModeType>("Nav", false, null, new[] {"Navigation"});
				if (navigationMode != null)
				{
					MovementBy =
						(navigationMode == NavigationModeType.CTM)
							? MovementByType.ClickToMoveOnly
							: (navigationMode == NavigationModeType.Mesh)
								? MovementByType.NavigatorPreferred
								: MovementByType.None;
				}

				// Pre-processing into a form we can use directly...
				for (int i = 0; i < InteractByGossipOptions.Length; ++i)
				{
					InteractByGossipOptions[i] -= 1;
				}
			}

			catch (Exception except)
			{
				// Maintenance problems occur for a number of reasons.  The primary two are...
				// * Changes were made to the behavior, and boundary conditions weren't properly tested.
				// * The Honorbuddy core was changed, and the behavior wasn't adjusted for the new changes.
				// In any case, we pinpoint the source of the problem area here, and hopefully it
				// can be quickly resolved.
				QBCLog.Exception(except);
				IsAttributeProblem = true;
			}
		}


		// Attributes provided by caller
		private int[] AuraIdsOnMob { get; set; }
		private int[] AuraIdsMissingFromMob { get; set; }
		private int BuyItemCount { get; set; }
		private double CollectionDistance { get; set; }
		private int[] FactionIds { get; set; }
		private WoWPoint HuntingGroundCenter { get; set; }
		private bool IgnoreCombat { get; set; }
		private bool IgnoreLoSToTarget { get; set; }
		private int InteractBlacklistTimeInSeconds { get; set; }
		private int InteractByBuyingItemId { get; set; }
		private int InteractByBuyingItemInSlotNum { get; set; }
		private int InteractByCastingSpellId { get; set; }
		private int[] InteractByGossipOptions { get; set; }
		private int InteractByUsingItemId { get; set; }
		private bool InteractByLooting { get; set; }
		private bool KeepTargetSelected { get; set; }
		private double MobHpPercentLeft { get; set; }
		private int[] MobIds { get; set; }
		private bool MobIdIncludesSelf { get; set; }
		private MobStateType MobState { get; set; }
		private bool NotMoving { get; set; }
		private int NumOfTimes { get; set; }
		private QuestFrameDisposition InteractByQuestFrameAction { get; set; }
		private MountStrategyType PreInteractMountStrategy { get; set; }
		private ProactiveCombatStrategyType ProactiveCombatStrategy { get; set; }
		private double? RangeMax { get; set; }
		private double? RangeMin { get; set; }
		private bool WaitForNpcs { get; set; }
		private int WaitTime { get; set; }

		protected override void EvaluateUsage_DeprecatedAttributes(XElement xElement)
		{
			UsageCheck_DeprecatedAttribute(
				xElement,
				(InteractByBuyingItemInSlotNum != -1),
				"InteractByBuyingItemInSlotNum/BuySlot",
				context => "The InteractByBuyingItemInSlotNum/BuySlot attributes have been deprecated.\n"
							+ "Please replace them with InteractByBuyingItemId attribute."
							+ "Your InteractByBuyingItemInSlotNum/BuySlot attribute will still be honored, but it may yield unexpected surprises,"
							+ " if the vendor is offering seasonal or other such items.");

			UsageCheck_DeprecatedAttribute(
				xElement,
				Args.Keys.Contains("Nav"),
				"Nav",
				context => string.Format(
					"Automatically converted Nav=\"{0}\" attribute into MovementBy=\"{1}\"."
					+ "  Please update profile to use MovementBy, instead.",
					Args["Nav"],
					MovementBy));

			UsageCheck_DeprecatedAttribute(
				xElement,
				Args.Keys.Contains("ObjectType"),
				"ObjectType",
				context => "The ObjectType attribute is no longer used by InteractWith."
							+ "  You may safely remove it from the profile call to the InteractWith behavior.");

			UsageCheck_DeprecatedAttribute(
				xElement,
				MobState == MobStateType.BelowHp,
				"MobState=\"BelowHp\"",
				context => "Please remove the 'MobState=\"BelowHp\"' attribute."
							+ "  The \"BelowHp\" value is no longer used, and has been deprecated."
							+ "  The \"MobHpPercentLeft\" attribute alone is sufficient to capture intent.");
		}


		protected override void EvaluateUsage_SemanticCoherency(XElement xElement)
		{
			UsageCheck_SemanticCoherency(
				xElement,
				!(MobIdIncludesSelf || MobIds.Any() || FactionIds.Any()),
				context => "You must specify one or more: MobIdIncludesSelf, MobIdN, FactionIdN");

			UsageCheck_SemanticCoherency(
				xElement,
				RangeMax.HasValue && RangeMin.HasValue && ((RangeMax.Value - RangeMin.Value) < RangeMinMaxEpsilon),
				context => string.Format(
					"Range({0}) must be at least {1} greater than MinRange({2}).",
					RangeMax.Value,
					RangeMinMaxEpsilon,
					RangeMin.Value));

			UsageCheck_SemanticCoherency(
				xElement,
				MobIdIncludesSelf && !((InteractByCastingSpellId > 0) || (InteractByUsingItemId > 0)),
				context => "When \"MobIdIncludesSelf\" is specified, one of the following attributes must also be specified:"
							+ "InteractByCastingSpellId, InteractByUsingItemId");
		}

		private enum NavigationModeType
		{
			Mesh,
			CTM,
			[UsedImplicitly] None,
		}

		private enum QuestFrameDisposition
		{
			Accept,
			Complete,
			Continue,
			Ignore,
			TerminateBehavior,
			TerminateProfile
		}

		#endregion

		#region Private and Convenience variables

		private const int AttemptCountMax = 7;
		private const double RangeMinMaxEpsilon = 3.0;
		private UtilityCoroutine.NoMobsAtCurrentWaypoint _noMobsAtCurrentWaypoint;
		private UtilityCoroutine.WaitForInventoryItem _waitForInventoryItem;
		private WaitTimer _waitTimerAfterInteracting = null;
		private WaitTimer _watchdogTimerToReachDestination = null;

		private BindingEventStateType BindingEventState { get; set; }
		private int Counter { get; set; }
		private int GossipPageIndex { get; set; }
		private HuntingGroundsType HuntingGrounds { get; set; }
		private int InteractAttemptCount { get; set; }

		private bool InteractByRightClick
		{
			get { return (InteractByUsingItemId == 0) && (InteractByCastingSpellId == 0); }
		}

		private WoWItem ItemToUse { get; set; }
		private WoWUnit SelectedAliveTarget { get; set; }
		private WoWObject SelectedTarget { get; set; }

		public override string SubversionId
		{
			get { return ("$Id: InteractWith.cs 1143 2013-12-24 01:27:50Z highvoltz $"); }
		}

		public override string SubversionRevision
		{
			get { return ("$Revision: 1143 $"); }
		}

		private enum BindingEventStateType
		{
			BindingEventUnhooked,
			BindingEventHooked,
			BindingEventFired,
		}

		#endregion

		#region Destructor, Dispose, and cleanup

		public override void OnFinished()
		{
			Targeting.Instance.IncludeTargetsFilter -= Instance_IncludeTargetsFilter;
			Targeting.Instance.RemoveTargetsFilter -= Instance_RemoveTargetsFilter;
			base.OnFinished();
		}

		#endregion

		#region Overrides of CustomForcedBehavior

		// CreateBehavior supplied by QuestBehaviorBase.
		// Instead, provide CreateMainBehavior definition.

		// Dispose supplied by QuestBehaviorBase.
		// Instead, provide CreateMainBehavior definition.

		// IsDone provided by QuestBehaviorBase.
		// Call the QuestBehaviorBase.BehaviorDone() method when you want to indicate your behavior is complete.

		// OnFinished provided by QuestBehaviorBase.

		public override void OnStart()
		{
			// Hunting ground processing...
			// NB: We had to defer this processing from the constructor, because XElement isn't available
			// to parse child XML nodes until OnStart() is called.
			HuntingGrounds = HuntingGroundsType.GetOrCreate(Element, "HuntingGrounds", HuntingGroundCenter);
			IsAttributeProblem |= HuntingGrounds.IsAttributeProblem;

			// Let QuestBehaviorBase do basic initializaion of the behavior, deal with bad or deprecated attributes,
			// capture configuration state, install BT hooks, etc.  This will also update the goal text.
			var isBehaviorShouldRun = OnStart_QuestBehaviorCore(GetGoalText());

			// If the quest is complete, this behavior is already done...
			// So we don't want to falsely inform the user of things that will be skipped.
			if (isBehaviorShouldRun)
			{
				// Setup settings to prevent interference with your behavior --
				// These settings will be automatically restored by QuestBehaviorBase when Dispose is called
				// by Honorbuddy, or the bot is stopped.

				// We need to disable 'pull distance' while this behavior in progress.
				// If we don't, HBcore tends to retarget things and pull them while we are in the middle of
				// an activity.
				CharacterSettings.Instance.PullDistance = 0;

				_waitTimerAfterInteracting = new WaitTimer(TimeSpan.FromMilliseconds(WaitTime));

				Targeting.Instance.IncludeTargetsFilter += Instance_IncludeTargetsFilter;

				Targeting.Instance.RemoveTargetsFilter += Instance_RemoveTargetsFilter;

				// NB: With the post-.557 HB releases, Honorbuddy will keep the NPC dialog boxes up
				// after a <PickUp> directive.  This looks more human like, and is a good thing.
				// Unfortunately, a <PickUp> immediate followed by an <InteractWith> will cause InteractWith
				// to see an unexpected quest dialog frame.  To prevent problems, we close all dialogs
				// when InteractWith is started, here.
				CloseOpenFrames(true);

				// If toon doesn't know any of the prescribed spells, we're done...
				if ((InteractByCastingSpellId > 0) && !SpellManager.HasSpell(InteractByCastingSpellId))
				{
					var message = string.Format("Toon doesn't know: {0}", Utility.GetSpellNameFromId(InteractByCastingSpellId));
					QBCLog.ProfileError(message);
					BehaviorDone(message);
				}
			}
		}

		#endregion

		#region Main Behaviors

		//protected override Composite CreateBehavior_CombatMain()
		//{
		//	return new Decorator(context => !IsDone, new PrioritySelector());
		//}

		protected override Composite CreateBehavior_CombatOnly()
		{
			return new PrioritySelector(
				new Action(
					context =>
					{
						// Force recalculation of time to reach destination after combat completes...
						_watchdogTimerToReachDestination = null;

						// If current target is not attackable, blacklist it...
						if ((Me.CurrentTarget != null) && !Me.CurrentTarget.Attackable)
						{
							Me.CurrentTarget.BlacklistForCombat(TimeSpan.FromSeconds(120));
							Me.ClearTarget();
						}

						// If we're ignoring combat, deprive Combat Routine of chance to run...
						return IgnoreCombat
							? RunStatus.Success
							: RunStatus.Failure;
					})
				);
		}


		protected override Composite CreateBehavior_DeathMain()
		{
			return new Action(
				ctx =>
				{
					if (Me.IsDead)
						SelectedTarget = null;
					return RunStatus.Failure;
				});
		}

		protected override Composite CreateMainBehavior()
		{
			return new ActionRunCoroutine(() => MainCoroutine());
		}

		private IEnumerator MainCoroutine()
		{
			if (IsDone)
			{
				yield return false;
				yield break;
			}

			// Delay, if necessary...
			// NB: We must do this prior to checking for 'behavior done'.  Otherwise, profiles
			// that don't have an associated quest, and put the behavior in a <While> loop will not behave
			// as the profile writer expects.  They expect the delay to be executed if the interaction
			// succeeded.
			if (!_waitTimerAfterInteracting.IsFinished)
			{
				TreeRoot.StatusText = string.Format(
					"Completing {0} wait of {1}",
					Utility.PrettyTime(TimeSpan.FromSeconds((int) _waitTimerAfterInteracting.TimeLeft.TotalSeconds)),
					Utility.PrettyTime(_waitTimerAfterInteracting.WaitTime));
				yield return true;
				yield break;
			}

			// Counter is used to determine 'done'...
			// NB: If QuestObjectiveIndex was specified, we don't care what counter is.  Instead,
			// we want the objective to complete.
			if (QuestObjectiveIndex == 0 && Counter >= NumOfTimes)
			{
				BehaviorDone(string.Format("Reached our required count of {0}.", NumOfTimes));
				yield return true;
				yield break;
			}

			// If WoWclient has not placed items in our bag, wait for it...
			// NB: This clumsiness is because Honorbuddy can launch and start using the behavior before the pokey
			// WoWclient manages to put the item into our bag after accepting a quest.  This delay waits
			// for the item to show up, if its going to.
			if (InteractByUsingItemId > 0 && !Query.IsViable(ItemToUse))
			{
				yield return
					_waitForInventoryItem ??
					(_waitForInventoryItem = new UtilityCoroutine.WaitForInventoryItem(() => InteractByUsingItemId, () => BehaviorDone()));

				// return if waiting for item to show up in bags.
				if ((bool) Coroutine.Current.LastResult)
				{
					yield break;
				}
				ItemToUse = Me.CarriedItems.FirstOrDefault(i => (i.Entry == InteractByUsingItemId));
			}

			// If interact target no longer meets qualifications, try to find another...
			if (!IsInteractNeeded(SelectedTarget, MobState))
			{
				CloseOpenFrames();
				Me.ClearTarget();
				SelectedTarget = FindViableTargets(MobState).FirstOrDefault();

				if (SelectedTarget != null)
				{
					this.UpdateGoalText(QuestId, GetGoalText());
					InteractAttemptCount = 0;
					_watchdogTimerToReachDestination = null;
				}

				// If we're looking for 'dead' targets, and there are none...
				// But, there are 'alive' targets that fit the bill, go convert the 'alive' ones to 'dead'.
				if ((SelectedTarget == null) && (MobState == MobStateType.Dead))
				{
					SelectedAliveTarget = FindViableTargets(MobStateType.Alive).FirstOrDefault() as WoWUnit;
					if (SelectedAliveTarget != null)
					{
						yield return true;
						yield break;
					}
				}
			}

			// break if we have something else to do.
			if (!Query.IsPoiIdle(BotPoi.Current))
			{
				yield return false;
				yield break;
			}

			// No mobs in immediate vicinity...
			// NB: if the terminateBehaviorIfNoTargetsProvider argument evaluates to 'true', calling
			// this sub-behavior will terminate the overall behavior.
			if (!Query.IsViable(SelectedTarget))
			{
				yield return
					_noMobsAtCurrentWaypoint ??
					(_noMobsAtCurrentWaypoint =
						new UtilityCoroutine.NoMobsAtCurrentWaypoint(
							() => HuntingGrounds,
							() => MovementBy,
							() => { if (!WaitForNpcs) BehaviorDone("Terminating--\"WaitForNpcs\" is false."); },
							() =>
								TargetExclusionAnalysis.Analyze(
									Element,
									() => Query.FindMobsAndFactions(MobIds, MobIdIncludesSelf, FactionIds),
									TargetExclusionChecks)));

				if ((bool) Coroutine.Current.LastResult)
					yield break;
			}

			#region Deal with mob we've selected for interaction...

			if (Query.IsViableForInteracting(SelectedTarget, IgnoreMobsInBlackspots, NonCompeteDistance))
			{
				yield return SubCoroutine_HandleFrame_Loot();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				yield return SubCoroutine_HandleFrame_Gossip();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				yield return SubCoroutine_HandleFrame_Merchant();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				yield return SubCoroutine_HandleFrame_Quest();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				yield return SubCoroutine_HandleFramesComplete();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				// If anything in the frame handling made the target no longer viable for interacting,
				// go find a new target...
				// NB: This mostly happens when NPCs close the gossip dialog on their end and walk away
				// or despawn, or outright go 'non viable' after the chat.
				if (!Query.IsViableForInteracting(SelectedTarget, IgnoreMobsInBlackspots, NonCompeteDistance))
				{
					yield return true;
					yield break;
				}

				#region Interact with, or use item on, selected target...

				// Show user the target that's interesting to us...
				// NB: If we've been in combat, our current target may remain on a dead body or other object.
				// This will confuse HB as we try to interact with an object.  So, we either guarantee that
				// a target is selected if it is a WoWUnit, or clear the target if its an object.
				var myTarget = Me.CurrentTarget;
				if (myTarget != SelectedTarget)
				{
					var wowUnit = SelectedTarget as WoWUnit;
					if ((wowUnit != null) && (IsWithinInteractDistance(wowUnit) || Query.IsInLineOfSight(wowUnit)))
					{
						Utility.Target(wowUnit);
					}
					else if (myTarget != null)
					{
						Me.ClearTarget();
					}
				}

				yield return SubCoroutine_DoMoveToTarget();
				if ((bool) Coroutine.Current.LastResult)
					yield break;

				// NB: We do the move before waiting for the cooldown.  The hope is that for most items, the
				// cooldown will have elapsed by the time we get within range of the next target.
				if (ItemToUse != null && ItemToUse.CooldownTimeLeft > TimeSpan.Zero)
				{
					TreeRoot.StatusText = string.Format(
						"Waiting for {0} cooldown ({1} remaining)",
						ItemToUse.Name,
						Utility.PrettyTime(TimeSpan.FromSeconds((int) ItemToUse.CooldownTimeLeft.TotalSeconds)));
					yield return true;
					yield break;
				}

				// If we've exceeded our maximum allowed attempts to interact, blacklist mob for a while...
				if (++InteractAttemptCount > AttemptCountMax)
				{
					var blacklistTime = BlacklistInteractTarget(SelectedTarget);

					QBCLog.Warning(
						"Exceeded our maximum count({0}) at attempted interactions--blacklisting {1} for {2}",
						AttemptCountMax,
						SelectedTarget.SafeName,
						Utility.PrettyTime(blacklistTime));
					yield return false;
					yield break;
				}

				// Interact by casting spell...
				if (InteractByCastingSpellId > 0)
				{
					yield return UtilityCoroutine.CastSpell(InteractByCastingSpellId, SelectedTarget);
				}

				// Interact by casting spell...
				if (InteractByUsingItemId > 0)
				{
					yield return
						UtilityCoroutine.UseItem(
							InteractByUsingItemId,
							SelectedTarget,
							() =>
								BehaviorDone(
									string.Format("Terminating behavior due to missing {0}", Utility.GetItemNameFromId(InteractByUsingItemId))));
				}

				// Interact by right-click..
				if (InteractByRightClick)
				{
					yield return UtilityCoroutine.Interact(SelectedTarget);
				}

				// Peg tally, if follow-up actions not expected...
				if (!IsFrameExpectedFromInteraction())
				{
					// NB: Some targets go invalid immediately after interacting with them.
					// So we must make certain that we don't intend to use such invalid targets
					// here.
					BlacklistInteractTarget(SelectedTarget);
					_waitTimerAfterInteracting.Reset();
					++Counter;

					if (IsClearTargetNeeded(SelectedTarget))
					{
						Me.ClearTarget();
					}

					SelectedTarget = null;
				}

				#endregion
			}

			#endregion

			yield return false;
		}

		#endregion

		#region Sub-Behaviors

		private IEnumerator SubCoroutine_DoMoveToTarget()
		{

			var isViableTarget = Query.IsViable(SelectedTarget);

			if (!isViableTarget)
			{
				_watchdogTimerToReachDestination = null;
			}

				// Watchdog only runs when not in combat...
			else if (!Me.Combat)
			{
				// If watchdog timer isn't running, start it...
				// NB: This places upper bound on time allowed to reach destination.  If a mob is bugged
				// or unreachable for some other reason, this timer will blacklist the mob when it expires.
				// Also, this timer will be terminated when we get in combat, so we may need to re-establish
				// it when combat completes.
				if (_watchdogTimerToReachDestination == null)
				{
					_watchdogTimerToReachDestination =
						new WaitTimer(
							SelectedTarget.Location.MaximumTraversalTime(2.5, TimeSpan.FromSeconds(20), TimeSpan.FromSeconds(180)));
					_watchdogTimerToReachDestination.Reset();
				}

				if (_watchdogTimerToReachDestination.IsFinished)
				{
					var blacklistTime = BlacklistInteractTarget(SelectedTarget);
					QBCLog.Warning(
						"Taking too long to reach {0}--blacklisting for {1}",
						SelectedTarget.SafeName,
						Utility.PrettyTime(blacklistTime));
					_watchdogTimerToReachDestination = null;
					isViableTarget = false;
				}
			}

			if (!isViableTarget)
			{
				yield return false;
				yield break;
			}

			if (IsDistanceGainNeeded(SelectedTarget) && RangeMin.HasValue)
			{
				var destinationName = string.Format(
					"gain distance from {0} (id:{1}, dist:{2:F1}/{3:F1})",
					GetName(SelectedTarget),
					SelectedTarget.Entry,
					SelectedTarget.Distance,
					RangeMin.Value);

				yield return UtilityCoroutine.MoveTo(
					Utility.GetPointToGainDistance(SelectedTarget, RangeMin.Value),
					destinationName,
					MovementBy);

				if ((bool) Coroutine.Current.LastResult)
					yield break;
			}
			if (IsDistanceCloseNeeded(SelectedTarget))
			{
				if (MovementBy == MovementByType.NavigatorOnly
					&& !Navigator.CanNavigateFully(StyxWoW.Me.Location, SelectedTarget.Location)
					&& (!Me.IsFlying || !Me.IsOnTransport))
				{
					TimeSpan blacklistDuration = BlacklistInteractTarget(SelectedTarget);
					TreeRoot.StatusText = string.Format(
						"Unable to navigate to {0} (dist: {1:F1})--blacklisting for {2}.",
						GetName(SelectedTarget),
						SelectedTarget.Distance,
						blacklistDuration);
					yield return true;
					yield break;
				}
				if (MovementBy == MovementByType.None)
				{
					TimeSpan blacklistDuration = BlacklistInteractTarget(SelectedTarget);
					TreeRoot.StatusText = string.Format(
						"{0} is out of range (dist: {1:F1})--blacklisting for {2}.",
						GetName(SelectedTarget),
						SelectedTarget.Distance,
						blacklistDuration);
					yield return true;
					yield break;
				}

				var destinationName = string.Format(
					"interact with {0} (id: {1}, dist: {2:F1}{3}, TtB: {4})",
					GetName(SelectedTarget),
					SelectedTarget.Entry,
					SelectedTarget.Distance,
					(Query.IsInLineOfSight(SelectedTarget) ? "" : ", noLoS"),
					// Time-to-Blacklist
					((_watchdogTimerToReachDestination != null)
						? Utility.PrettyTime(_watchdogTimerToReachDestination.TimeLeft)
						: "\u8734"));

				yield return UtilityCoroutine.MoveTo(SelectedTarget.Location, destinationName, MovementBy);
				if ((bool) Coroutine.Current.LastResult)
					yield break;
			}

			// Prep to interact...
			yield return UtilityCoroutine.MoveStop();
			yield return UtilityCoroutine.ExecuteMountStrategy(PreInteractMountStrategy);
			if ((bool) Coroutine.Current.LastResult)
				yield break;

			_watchdogTimerToReachDestination = null;
			// Face target...
			Utility.Target(SelectedTarget, true);
			yield return false;
		}


		private IEnumerator SubCoroutine_HandleFramesComplete()
		{
			if (IsGossipFrameVisible
				|| IsMerchantFrameVisible
				|| IsQuestFrameVisible
				|| IsTaxiFrameVisible
				|| IsTrainerFrameVisible)
			{
				TreeRoot.StatusText = string.Format("Interaction with {0} complete.", GetName(SelectedTarget));
				CloseOpenFrames();
				_waitTimerAfterInteracting.Reset();

				// Some mobs go non-viable immediately after interacting with them...
				if (Query.IsViable(SelectedTarget))
				{
					BlacklistInteractTarget(SelectedTarget);
					if (IsClearTargetNeeded(SelectedTarget))
					{
						Me.ClearTarget();
					}
				}

				SelectedTarget = null;
				yield return true;
				yield break;
			}

			// Some mobs go non-viable immediately after interacting with them...
			// For instance, interacting with mobs that give you automatic taxi rides.
			// We must guard against trying to interact with them further.
			if (!Query.IsViable(SelectedTarget))
			{
				SelectedTarget = null;
				yield return true;
				yield break;
			}
			yield return false;
		}


		private IEnumerator SubCoroutine_HandleFrame_Gossip()
		{
			if (IsGossipFrameVisible)
			{
				if (InteractByGossipOptions.Length > 0)
				{
					TreeRoot.StatusText = string.Format("Gossiping with {0}", GetName(SelectedTarget));
					BindingEventState = BindingEventStateType.BindingEventUnhooked;
					GossipPageIndex = 0;
					while (!IsDone && GossipPageIndex < InteractByGossipOptions.Length)
					{
						GossipEntry gossipEntry;
						if (!TryGetGossipEntry(out gossipEntry))
						{
							QBCLog.Error(
								"{0} is not offering gossip option {1} on page {2}."
								+ "  Did competing player alter NPC state?"
								+ "  Did you stop/start Honorbuddy?"
								+ "  Terminating behavior.",
								GetName(SelectedTarget),
								InteractByGossipOptions[GossipPageIndex] + 1,
								GossipPageIndex + 1);
							CloseOpenFrames();
							Me.ClearTarget();
							BehaviorDone();
							yield break;
						}

						// Log the gossip option we're about to take...
						QBCLog.DeveloperInfo(
							"Selecting Gossip Option({0}) on page {1}: \"{2}\"",
							gossipEntry.Index + 1,
							GossipPageIndex + 1,
							gossipEntry.Text);

						// If Innkeeper 'binding option', arrange to confirm ensuing popup...
						if (gossipEntry.Type == GossipEntry.GossipEntryType.Binder)
						{
							BindingEventState = BindingEventStateType.BindingEventHooked;
							Lua.Events.AttachEvent("CONFIRM_BINDER", HandleConfirmForBindingAtInn);
						}

						GossipFrame.Instance.SelectGossipOption(InteractByGossipOptions[GossipPageIndex]);
						++GossipPageIndex;

						// If gossip is complete, claim credit...
						// Frequently, the last gossip option in a chain will start a fight.  If this happens,
						// and we don't claim credit, the behavior will hang trying to re-try a gossip with the NPC,
						// and the NPC doesn't want to gossip any more.
						if (GossipPageIndex >= InteractByGossipOptions.Length)
						{
							QBCLog.DeveloperInfo("Gossip with {0} complete.", GetName(SelectedTarget));

							// NB: Some merchants require that we gossip with them before purchase.
							// If the caller has also specified a "buy item", then we're not done yet.
							if ((InteractByBuyingItemId <= 0) && (InteractByBuyingItemInSlotNum <= 0))
							{
								BlacklistInteractTarget(SelectedTarget);
								_waitTimerAfterInteracting.Reset();
								++Counter;
							}
						}
						yield return StyxCoroutine.Wait((int) Delay.AfterInteraction.TotalMilliseconds, () => !IsGossipFrameVisible);
					}
					// If the NPC pops down the dialog for us, or goes non-viable after gossip...
					// Go ahead and blacklist it, so we don't try to interact again.

					if (!IsGossipFrameVisible || !Query.IsViable(SelectedTarget))
					{
						TreeRoot.StatusText = string.Format("Gossip with {0} complete.", GetName(SelectedTarget));
						_waitTimerAfterInteracting.Reset();
						++Counter;

						BlacklistInteractTarget(SelectedTarget);
						if (IsClearTargetNeeded(SelectedTarget))
						{
							Me.ClearTarget();
						}
					}
				}
				// Only a problem if Gossip frame, and not also another frame type...
				if ((InteractByGossipOptions.Length <= 0) && IsGossipFrameVisible && !IsMultipleFramesVisible())
				{
					QBCLog.Warning("[PROFILE ERROR]: Gossip frame not expected--ignoring.");
				}
				yield return StyxCoroutine.Sleep((int) Delay.AfterInteraction.TotalMilliseconds);
			}

			// Tell user if he is now bound to a new location...
			if (BindingEventState != BindingEventStateType.BindingEventUnhooked)
			{
				yield return StyxCoroutine.Wait(10000, () => BindingEventState == BindingEventStateType.BindingEventFired);
				if ((bool) Coroutine.Current.LastResult)
				{
					yield return StyxCoroutine.Sleep((int) Delay.AfterInteraction.TotalMilliseconds);
					Lua.DoString("ConfirmBinder(); StaticPopup_Hide('CONFIRM_BINDER')");
					// NB: We give the WoWclient a little time to register our new location
					// before asking it "where is our hearthstone set?"
					yield return StyxCoroutine.Sleep(1000);
					var boundLocation = Lua.GetReturnVal<string>("return GetBindLocation()", 0);

					QBCLog.Info(
						"You are now bound at {0} Inn in {1}({2})",
						(Query.IsViable(SelectedTarget) ? GetName(SelectedTarget) : "the"),
						boundLocation,
						Me.HearthstoneAreaId);

					BindingEventState = BindingEventStateType.BindingEventUnhooked;
					Lua.Events.DetachEvent("CONFIRM_BINDER", HandleConfirmForBindingAtInn);
				}
			}
			yield return false;
		}

		private IEnumerator SubCoroutine_HandleFrame_Loot()
		{
			// Nothing really special for us to do here.  HBcore will take care of 'normal' looting.
			// And looting objects through "interaction" is usually nothing more than right-clicking
			// on the object and a loot frame is not even produced.  But this is here, just in case
			// a loot frame is produced, and HBcore doesn't deal with it.
			if (LootFrame.Instance.IsVisible)
			{
				TreeRoot.StatusText = string.Format("Looting {0}", GetName(SelectedTarget));
				LootFrame.Instance.LootAll();
				yield return StyxCoroutine.Sleep((int) Delay.AfterInteraction.TotalMilliseconds);
			}
			// we want to 'fall through'
			yield return false;
		}

		private IEnumerator SubCoroutine_HandleFrame_Merchant()
		{
			if (!IsMerchantFrameVisible)
			{
				yield return false;
				yield break;
			}

			if ((InteractByBuyingItemId > 0) || (InteractByBuyingItemInSlotNum >= 0))
			{
				MerchantItem item = (InteractByBuyingItemId > 0)
					? MerchantFrame.Instance.GetAllMerchantItems().FirstOrDefault(i => i.ItemId == InteractByBuyingItemId)
					: (InteractByBuyingItemInSlotNum >= 0)
						? MerchantFrame.Instance.GetMerchantItemByIndex(InteractByBuyingItemInSlotNum)
						: null;

				if (item == null)
				{
					if (InteractByBuyingItemId > 0)
					{
						QBCLog.ProfileError(
							"{0} does not appear to carry ItemId({1})--abandoning transaction.",
							GetName(SelectedTarget),
							InteractByBuyingItemId);
					}
					else
					{
						QBCLog.ProfileError(
							"{0} does not have an item to sell in slot #{1}--abandoning transaction.",
							GetName(SelectedTarget),
							InteractByBuyingItemInSlotNum);
					}
				}
				else if ((item.BuyPrice*(ulong) BuyItemCount) > Me.Copper)
				{
					QBCLog.ProfileError(
						"Toon does not have enough money to purchase {0} (qty: {1})"
						+ "--(requires: {2}, have: {3})--abandoning transaction.",
						item.Name,
						BuyItemCount,
						Utility.PrettyMoney(item.BuyPrice*(ulong) BuyItemCount),
						Utility.PrettyMoney(Me.Copper));
				}
				else if ((item.NumAvailable != /*unlimited*/ -1) && (item.NumAvailable < BuyItemCount))
				{
					QBCLog.ProfileError(
						"{0} only has {1} units of {2} (we need {3})--abandoning transaction.",
						GetName(SelectedTarget),
						item.NumAvailable,
						item.Name,
						BuyItemCount);
				}
				else
				{
					QBCLog.Info("Buying {0} (qty: {1}) from {2}", item.Name, BuyItemCount, GetName(SelectedTarget));
					MerchantFrame.Instance.BuyItem(item.Index, BuyItemCount);
				}
				// NB: We do not blacklist merchants.
				++Counter;
			}

			else if (!IsMultipleFramesVisible())
			{
				QBCLog.Warning("[PROFILE ERROR] Merchant frame not expected--ignoring.");
			}

			yield return StyxCoroutine.Sleep((int) Delay.AfterInteraction.TotalMilliseconds);
			// we want to 'fall through'
			yield return false;
		}

		private IEnumerator SubCoroutine_HandleFrame_Quest()
		{
			if (!IsQuestFrameVisible)
			{
				yield return false;
				yield break;
			}

			if (InteractByQuestFrameAction == QuestFrameDisposition.Accept)
				QuestFrame.Instance.AcceptQuest();
			else if (InteractByQuestFrameAction == QuestFrameDisposition.Complete)
				QuestFrame.Instance.CompleteQuest();
			else if (InteractByQuestFrameAction == QuestFrameDisposition.Continue)
				QuestFrame.Instance.ClickContinue();

			// If the NPC pops down the dialog for us, or goes non-viable after gossip...
			// Go ahead and blacklist it, so we don't try to interact again.
			if (!IsQuestFrameVisible || !Query.IsViable(SelectedTarget))
			{
				TreeRoot.StatusText = string.Format("Quest accept from {0} complete.", GetName(SelectedTarget));
				_waitTimerAfterInteracting.Reset();
				++Counter;

				BlacklistInteractTarget(SelectedTarget);
				if (IsClearTargetNeeded(SelectedTarget))
				{
					Me.ClearTarget();
				}
			}
			if (InteractByQuestFrameAction == QuestFrameDisposition.Ignore)
				QuestFrame.Instance.Close();

			if (!IsMultipleFramesVisible())
			{
				if (InteractByQuestFrameAction == QuestFrameDisposition.TerminateBehavior)
				{
					QBCLog.DeveloperInfo(
						"Behavior Done--due to {0} providing a quest frame, and InteractByQuestFrameDisposition=TerminateBehavior",
						GetName(SelectedTarget));
					CloseOpenFrames(true);
					BehaviorDone();
				}

				if (InteractByQuestFrameAction == QuestFrameDisposition.TerminateProfile)
				{
					QBCLog.ProfileError(
						"{0} provided an unexpected Quest frame--terminating profile."
						+ "  Please provide an appropriate InteractByQuestFrameDisposition attribute to instruct"
						+ " the behavior how to handle this situation.",
						GetName(SelectedTarget));
					CloseOpenFrames(true);
					BehaviorDone();
				}
			}
			yield return StyxCoroutine.Sleep((int) Delay.AfterInteraction.TotalMilliseconds);
			// we want to 'fall through'
			yield return false;
		}

		#endregion

		#region Targeting

		private void Instance_IncludeTargetsFilter(List<WoWObject> incomingUnits, HashSet<WoWObject> outgoingUnits)
		{
			var isActuallyInCombat = Me.IsActuallyInCombat;

			var clearMobsThatWillAggro = ProactiveCombatStrategy == ProactiveCombatStrategyType.ClearAll
										|| ProactiveCombatStrategy == ProactiveCombatStrategyType.ClearMobsThatWillAggro;

			var selectedUnit = SelectedTarget as WoWUnit;
			// If we expect to gossip, and mob in combat and offers no gossip, help mob...
			// NB: Mobs frequently will not offer their gossip options while they are in combat.
			if (InteractByGossipOptions.Length > 0 && selectedUnit != null && selectedUnit.Combat)
			{
				var selectetUnitTarget = selectedUnit.CurrentTarget;
				outgoingUnits.Add(selectetUnitTarget);
			}

			// if we have a target that needs to be killed before interaction can take place then make it so.
			if (Query.IsViable(SelectedAliveTarget) && SelectedAliveTarget.IsAlive)
				outgoingUnits.Add(SelectedAliveTarget);

			foreach (var unit in incomingUnits.OfType<WoWUnit>())
			{
				if (isActuallyInCombat)
					continue;

				if (!clearMobsThatWillAggro)
					continue;

				if (SelectedTarget == null)
					continue;

				if (!unit.IsHostile)
					continue;

				if (!unit.IsUntagged())
					continue;

				if (unit.PlayerControlled)
					continue;

				if (unit.Location.PathTraversalCost(unit.Location) > (unit.MyAggroRange + unit.InteractRange))
					continue;

				outgoingUnits.Add(unit);
			}
		}

		private void Instance_RemoveTargetsFilter(List<WoWObject> units)
		{
			var removeViableTargets = InteractAttemptCount == 0 || Query.FindMobsAttackingMe().Count() <= 1;

			var clearMobsThatWillAggro = ProactiveCombatStrategy == ProactiveCombatStrategyType.ClearAll
										|| ProactiveCombatStrategy == ProactiveCombatStrategyType.ClearMobsThatWillAggro;
			units.RemoveAll(
				o =>
				{
					if (IgnoreCombat)
						return true;

					if (Me.IsFlying)
						return true;

					var unit = (WoWUnit) o;

					if (!Me.IsActuallyInCombat)
					{
						if (unit == SelectedAliveTarget)
							return false;

						if (!Query.IsStateMatch_IgnoreMobsInBlackspots(unit, IgnoreMobsInBlackspots))
							return true;

						if (Query.IsInCompetition(unit, NonCompeteDistance))
							return true;

						// Do not pull mobs on the AvoidMobs list
						if ( ProfileManager.CurrentOuterProfile.AvoidMobs.Contains(unit.Entry))
							return true;

						if (!clearMobsThatWillAggro)
							return true;

						// because linear distance check is cheaper than path distance check we eliminate all that fall outside of linear aggro range distance first
						var aggroRange = unit.MyAggroRange + unit.InteractRange;
						if (unit.Distance > aggroRange)
							return true;

						if (unit.Location.PathTraversalCost(Me.Location) > aggroRange)
							return true;
					}

					// exclude any units that are candidates for interacting unless we are attacked by multiple units.
					if (removeViableTargets && IsViableInteractTarget(unit))
						return true;

					return false;
				});
		}

		#endregion

		#region Helpers

		private PerFrameCachedValue<bool> _isGossipFrameVisible;

		private PerFrameCachedValue<bool> _isLootFrameVisible;

		private PerFrameCachedValue<bool> _isMerchantFrameVisible;

		private PerFrameCachedValue<bool> _isQuestFrameVisible;

		private PerFrameCachedValue<bool> _isTaxiFrameVisible;

		private PerFrameCachedValue<bool> _isTrainerFrameVisible;

		// cache the 'IsVisible' results for one frame to help increase performance.
		// Note: change to use TimeCachedValue once it goes live. 
		private bool IsLootFrameVisible
		{
			get
			{
				return _isLootFrameVisible ??
						(_isLootFrameVisible = new PerFrameCachedValue<bool>(() => LootFrame.Instance.IsVisible));
			}
		}

		private bool IsGossipFrameVisible
		{
			get
			{
				return _isGossipFrameVisible ??
						(_isGossipFrameVisible = new PerFrameCachedValue<bool>(() => GossipFrame.Instance.IsVisible));
			}
		}

		private bool IsMerchantFrameVisible
		{
			get
			{
				return _isMerchantFrameVisible ??
						(_isMerchantFrameVisible =
							new PerFrameCachedValue<bool>(() => MerchantFrame.Instance.IsVisible));
			}
		}

		private bool IsQuestFrameVisible
		{
			get
			{
				return _isQuestFrameVisible ??
						(_isQuestFrameVisible = new PerFrameCachedValue<bool>(() => QuestFrame.Instance.IsVisible));
			}
		}

		private bool IsTaxiFrameVisible
		{
			get
			{
				return _isTaxiFrameVisible ??
						(_isTaxiFrameVisible = new PerFrameCachedValue<bool>(() => TaxiFrame.Instance.IsVisible));
			}
		}

		private bool IsTrainerFrameVisible
		{
			get
			{
				return _isTrainerFrameVisible ??
						(_isTrainerFrameVisible =
							new PerFrameCachedValue<bool>(() => TrainerFrame.Instance.IsVisible));
			}
		}

		private TimeSpan BlacklistInteractTarget(WoWObject selectedTarget)
		{
			// NB: The selectedTarget can sometimes go "non viable" immediately upon interaction.
			// An example: We gossip with an NPC that results in a forced taxi ride.  Honorbuddy suspends
			// this behavior while the taxi ride is in progress, and when we land, the selectedTarget
			// is no longer viable to blacklist.
			if (!Query.IsViable(selectedTarget))
			{
				return TimeSpan.Zero;
			}

			var wowUnit = selectedTarget as WoWUnit;
			bool isShortBlacklist = (wowUnit != null) && ((wowUnit == Me) || Query.IsSharedWorldResource(wowUnit));
			TimeSpan blacklistDuration = TimeSpan.FromSeconds(isShortBlacklist ? 30 : InteractBlacklistTimeInSeconds);

			selectedTarget.BlacklistForInteracting(blacklistDuration);
			return blacklistDuration;
		}


		private void CloseOpenFrames(bool forceClose = false)
		{
			if (forceClose || IsClearTargetNeeded(SelectedTarget))
			{
				Utility.CloseAllNpcFrames();
			}
		}


		/// <summary> Current object we should interact with.</summary>
		/// <value> The object.</value>
		private IEnumerable<WoWObject> FindViableTargets(MobStateType mobState)
		{
			const double minionWeighting = 1000;

			using (StyxWoW.Memory.AcquireFrame())
			{
				var entities =
					from wowObject in Query.FindMobsAndFactions(MobIds, MobIdIncludesSelf, FactionIds)
					where
						Query.IsViable(wowObject)
						&& IsInteractNeeded(wowObject, mobState)
						&& Query.IsStateMatch_MeshNavigable(wowObject, MovementBy)
					let objectCollectionDistance = wowObject.Location.CollectionDistance()
					where
						objectCollectionDistance <= CollectionDistance
					orderby
						objectCollectionDistance
							// Fix for undead-quest (and maybe some more), where the targets can be minions...
						+ (Me.Minions.Contains(wowObject) ? minionWeighting : 1)
							// Make sure 'self' is always last on the list, otherwise we'll ignore all other Mobs...
						+ (wowObject.IsMe ? 1000 : 0)
					select wowObject;

				return entities.ToList();
			}
		}


		private string GetGoalText()
		{
			var action =
				(InteractByUsingItemId > 0)
					? string.Format("by using {0} on", Utility.GetItemNameFromId(InteractByUsingItemId))
					: (InteractByCastingSpellId > 0)
						? string.Format("by casting {0} on", Utility.GetSpellNameFromId(InteractByCastingSpellId))
						: "with";

			var targetNames = string.Join(", ", MobIds.Select(m => Utility.GetObjectNameFromId(m)).Distinct());
			if (MobIdIncludesSelf)
			{
				targetNames = string.Join(", ", "Self", targetNames);
			}

			return string.Format("Interacting {0} {1}", action, targetNames);
		}


		/// <summary>
		///     The SelectedInteractTarget may no longer be viable after interacting with it.
		///     For instance, the NPC may disappear, or if the toon was forced on a taxi ride
		///     as a result of the gossip, the SelectedInteractTarget will no longer be viable
		///     once we land.
		/// </summary>
		private string GetName(WoWObject target)
		{
			return Query.IsViable(target)
				? target.Name
				: (target == SelectedTarget)
					? "selected target"
					: (target.ToUnit() != null)
						? "unit"
						: "object";
		}


		private void HandleConfirmForBindingAtInn(object sender, LuaEventArgs args)
		{
			BindingEventState = BindingEventStateType.BindingEventFired;
		}


		private bool IsClearTargetNeeded(WoWObject wowObject)
		{
			if (!Query.IsViable(wowObject))
			{
				return false;
			}

			var wowUnit = wowObject as WoWUnit;

			return
				(wowUnit != null)
				&& (Me.CurrentTargetGuid == wowUnit.Guid)
				&& !KeepTargetSelected;
		}


		private bool IsDistanceCloseNeeded(WoWObject wowObject)
		{
			bool canInteract = IsWithinInteractDistance(wowObject);

			// Item usage must be additionally qualified by LoS constraints...
			if (ItemToUse != null)
			{
				canInteract &= (IgnoreLoSToTarget || Query.IsInLineOfSight(wowObject));
			}

			return !canInteract;
		}


		private bool IsDistanceGainNeeded(WoWObject wowObject)
		{
			if (!RangeMin.HasValue)
			{
				return false;
			}

			double targetDistance = WoWMovement.ActiveMover.Location.Distance(wowObject.Location);

			return targetDistance < RangeMin.Value;
		}


		private bool IsFrameExpectedFromInteraction()
		{
			// NB: InteractByLoot is nothing more than a normal "right click" activity
			// on something. If something is normally 'lootable', HBcore will deal with it.
			return
				(InteractByBuyingItemId > 0)
				|| (InteractByBuyingItemInSlotNum > -1)
				|| (InteractByGossipOptions.Length > 0)
				|| (InteractByQuestFrameAction == QuestFrameDisposition.Accept)
				|| (InteractByQuestFrameAction == QuestFrameDisposition.Complete)
				|| (InteractByQuestFrameAction == QuestFrameDisposition.Continue);
		}


		// 24Feb2013-08:11UTC chinajade
		private bool IsInteractNeeded(WoWObject wowObject, MobStateType mobState)
		{
			if (wowObject == null)
			{
				return false;
			}

			bool isViableForInteracting = Query.IsViableForInteracting(wowObject, IgnoreMobsInBlackspots, NonCompeteDistance);
			WoWUnit wowUnit = wowObject as WoWUnit;

			// We're done, if not a WoWUnit...
			if (wowUnit == null)
			{
				return isViableForInteracting;
			}

			// Additional qualifiers for WoWUnits...        
			return
				isViableForInteracting
				&& Query.IsStateMatch_NotMoving(wowUnit, NotMoving)
					// Many times, units can't gossip unti they're out of combat.  So, assume they can gossip if they are in combat...
					// Once out of combat, we can re-evaluate whether this was a good choice or not.w
				&& ((InteractByGossipOptions.Length <= 0) || wowUnit.Combat || wowUnit.CanGossip)
				&& Query.IsStateMatch_AurasWanted(wowUnit, AuraIdsOnMob)
				&& Query.IsStateMatch_AurasMissing(wowUnit, AuraIdsMissingFromMob)
				&& Query.IsStateMatch_MobState(wowObject, mobState, MobHpPercentLeft);
		}


		private bool IsMultipleFramesVisible()
		{
			int score =
				(IsGossipFrameVisible ? 1 : 0)
				+ (IsMerchantFrameVisible ? 1 : 0)
				+ (IsQuestFrameVisible ? 1 : 0)
				+ (IsTaxiFrameVisible ? 1 : 0)
				+ (IsTrainerFrameVisible ? 1 : 0);

			return score > 1;
		}

		private bool IsViableInteractTarget(WoWObject wowObject)
		{
			if (!Query.IsMobOrFaction(wowObject, MobIds, MobIdIncludesSelf, FactionIds))
				return false;

			if (!IsInteractNeeded(wowObject, MobState))
				return false;

			if (!Query.IsStateMatch_MeshNavigable(wowObject, MovementBy))
				return false;

			return wowObject.Location.CollectionDistance() <= CollectionDistance;
		}


		private bool IsWithinInteractDistance(WoWObject wowObject)
		{
			return
				Query.IsViable(wowObject)
				&& (RangeMax.HasValue
					// If user specified MaxRange, honor its value...
					? (WoWMovement.ActiveMover.Location.Distance(wowObject.Location) <= RangeMax.Value)
					// Otherwise, prefer target's definition of its interact distance...
					: wowObject.WithinInteractRange);
		}


		// 4JUn2013-08:11UTC chinajade
		private List<string> TargetExclusionChecks(WoWObject wowObject)
		{
			var exclusionReasons = TargetExclusionAnalysis.CheckCore(wowObject, this);

			TargetExclusionAnalysis.CheckAuras(exclusionReasons, wowObject, AuraIdsOnMob, AuraIdsMissingFromMob);
			TargetExclusionAnalysis.CheckMobState(exclusionReasons, wowObject, MobState, MobHpPercentLeft);

			var objectCollectionDistance = wowObject.Location.CollectionDistance();
			if (objectCollectionDistance > CollectionDistance)
			{
				exclusionReasons.Add(
					string.Format("ExceedsCollectionDistance({0:F1}, saw {1:F1})", CollectionDistance, objectCollectionDistance));
			}

			var wowUnit = wowObject as WoWUnit;
			if (wowUnit != null)
			{
				if (!Query.IsStateMatch_NotMoving(wowUnit, NotMoving))
				{
					exclusionReasons.Add("Moving");
				}

				if ((InteractByGossipOptions.Length > 0) && !wowUnit.CanGossip)
				{
					exclusionReasons.Add("NoGossip");
				}
			}

			return exclusionReasons;
		}

		private bool TryGetGossipEntry(out GossipEntry gossipEntry)
		{
			try
			{
				// NB: This clumsiness is because HB defines the default GossipEntry with an
				// an Index of 0.  Since this is a valid gossip option index, this leaves us with
				// no way to determine the difference between the 'default' value, and a valid
				// value. So, we try to get the gossip entry using First() (vs. FirstOrDefault()),
				// and if an exception gets thrown, we know the entry is not present.
				if (GossipFrame.Instance.GossipOptionEntries == null)
				{
					throw new InvalidOperationException();
				}

				gossipEntry = GossipFrame.Instance.GossipOptionEntries
					.First(o => o.Index == InteractByGossipOptions[GossipPageIndex]);
			}
			catch (InvalidOperationException)
			{
				gossipEntry = new GossipEntry();
				return false;
			}
			return true;
		}

		#endregion
	}
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;
using System.Windows.Media;
using Bots.DungeonBuddy.Avoidance;
using Bots.DungeonBuddy.Behaviors;
using Bots.DungeonBuddy.Profiles.Handlers;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Coroutines;
using Styx.CommonBot.Frames;
using Styx.CommonBot.POI;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.World;
using Action = Styx.TreeSharp.Action;
using Bots.DungeonBuddy.Profiles;
using Bots.DungeonBuddy.Attributes;
using Bots.DungeonBuddy.Helpers;
using AvoidanceManager = Bots.DungeonBuddy.Avoidance.AvoidanceManager;
using Vector2 = Tripper.Tools.Math.Vector2;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
{
	public class TheUnderhold : Dungeon
	{
		#region Overrides of Dungeon

		public override uint DungeonId
		{
			get { return 724; }
		}

		public override WoWPoint Entrance
		{
			get { return new WoWPoint(1242.479, 600.5036, 318.0787); }
		}

		#region Movement

		private const uint LiftHookId = 72972;

		public override MoveResult MoveTo(WoWPoint location)
		{
			var myLoc = Me.Location;
			var mySopQuad = GetQuadrantAtLocation(myLoc);
			// use the lifts in at Spoils of Pandoria encounter
			if (mySopQuad != PosQuadrant.None && !Me.IsOnTransport)
			{
				if (!IsInMyQuadrants(mySopQuad, location))
				{
					// CR or whatever wants to move outside of assigned section. block movement request.
					if (DoingSpoilsOfPandariaEncounter)
						return MoveResult.Moved;

					// can't use lift while in combat

					var lift =
						ObjectManager.GetObjectsOfTypeFast<WoWUnit>()
							.Where(u => u.Entry == LiftHookId && IsInMyQuadrants(mySopQuad, u.Location) && u.HasAura("Lift Hook"))
							.OrderBy(u => u.DistanceSqr)
							.FirstOrDefault();
					if (lift != null)
					{
						// need to pretty much stand under the lift before interacting.
						if (lift.Distance2DSqr > 1.5*1.5)
							return Navigator.MoveTo(lift.Location);
						if (Me.IsMoving)
							WoWMovement.MoveStop();
						lift.Interact();
						return MoveResult.Moved;
					}
				}
			}
			return MoveResult.Failed;
		}

		#endregion

		public override void RemoveTargetsFilter(List<WoWObject> units)
		{
			var combat = Me.Combat;
			var sopNotComplete = ScriptHelpers.IsBossAlive("Spoils of Pandoria");
			var mySopQuad = sopNotComplete ? GetQuadrantAtLocation(Me.Location) : PosQuadrant.None;

			var sop_leaderQuad = sopNotComplete && _spoilsOfPandoriaLeader != null && _spoilsOfPandoriaLeader.IsValid
				? GetQuadrantAtLocation(_spoilsOfPandoriaLeader.Location)
				: PosQuadrant.None;


			var onSpoilsOfPandariaEncounter = sopNotComplete && (mySopQuad != PosQuadrant.None || sop_leaderQuad != PosQuadrant.None);

			units.RemoveAll(
				ret =>
				{
					var unit = ret.ToUnit();
					if (unit != null)
					{
						// remove all units that are not in my quadrant while doing the Spoils of Pandarian encounter
						if (combat && onSpoilsOfPandariaEncounter && !IsInMyQuadrants(mySopQuad, unit.Location))
						{
							return true;
						}
					}
					return false;
				});
		}

		public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
		{
			foreach (var obj in incomingunits)
			{
				var unit = obj as WoWUnit;
				if (unit != null)
				{
					if (unit.Entry == IceTombId && unit.DistanceSqr < 40*40)
					{
						outgoingunits.Add(unit);
					}
				}
			}
		}

		public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
		{
			foreach (var priority in units)
			{
				var unit = priority.Object as WoWUnit;
				if (unit != null)
				{
					switch (unit.Entry)
					{
							// these do heals so need to be dealt with first
						case ZarthikAmberPriestId:
							// break out group members from the ice tomb
						case IceTombId:
							priority.Score += 5000;
							break;
					}
				}
			}
		}

		public override void RemoveHealTargetsFilter(List<WoWObject> units)
		{
			var combat = Me.Combat;
			var sopNotComplete = ScriptHelpers.IsBossAlive("Spoils of Pandoria");
			var mySopQuad = sopNotComplete ? GetQuadrantAtLocation(Me.Location) : PosQuadrant.None;

			var sop_leaderQuad = sopNotComplete && _spoilsOfPandoriaLeader != null && _spoilsOfPandoriaLeader.IsValid
				? GetQuadrantAtLocation(_spoilsOfPandoriaLeader.Location)
				: PosQuadrant.None;


			var onSpoilsOfPandariaEncounter = sopNotComplete && (mySopQuad != PosQuadrant.None || sop_leaderQuad != PosQuadrant.None);

			units.RemoveAll(
				ret =>
				{
					var unit = ret.ToUnit();
					if (unit != null)
					{
						// remove all units that are not in my quadrant while doing the Spoils of Pandarian encounter
						if (combat && onSpoilsOfPandariaEncounter && !IsInMyQuadrants(mySopQuad, unit.Location))
						{
							return true;
						}
					}
					return false;
				});
		}

		public override void OnEnter()
		{
			if (Me.IsTank())
			{
				Alert.Show(
					"Tanking Not Supported",
					string.Format(
						"Tanking is not supported in the {0} script. If you wish to stay in raid and play manually then press 'Continue'. Otherwise you will automatically leave raid.",
						Name),
					30,
					true,
					true,
					null,
					() => Lua.DoString("LeaveParty()"),
					"Continue",
					"Leave");
			}
			else
			{
				Alert.Show(
					"Do Not AFK",
					"It is highly recommended you do not afk while in a raid and be prepared to intervene if needed in the event something goes wrong or you're asked to perform a certain task.",
					20,
					true,
					false,
					null,
					null,
					"Ok");
			}
		}

		#endregion

		#region Root Behavior

		private const uint AcidSpraySpellId = 146978;
		private const uint ScorchedEarthSpellId = 146225;
		private const uint ScorchedEarthMissileId = 146221;

		private LocalPlayer Me
		{
			get { return StyxWoW.Me; }
		}

		[EncounterHandler(0)]
		public Composite RootBehavior()
		{
			// avoid the acid spray used by trash.
			AddAvoidObject(
				ctx => true,
				9,
				o =>
				{
					var areaTrigger = o as WoWAreaTrigger;
					return areaTrigger != null && areaTrigger.SpellId == AcidSpraySpellId;
				});

			// avoid Scorched Earth used by trash at entrance
			AddAvoidObject(
				ctx => true,
				4,
				o =>
				{
					var areaTrigger = o as WoWAreaTrigger;
					return areaTrigger != null && areaTrigger.SpellId == ScorchedEarthSpellId;
				});

			// avoid Scorched Earth used by trash at entrance
			AddAvoidLocation(
				ctx => true,
				4,
				m => ((WoWMissile) m).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == ScorchedEarthMissileId));
			return new PrioritySelector();
		}

		#endregion

		#region Malkorok

		private const int BloodRageSpellId = 142879;
		private const int ArcingSmashSpellId = 143805;
		private const uint BreathOfYShaarjId = 142842;
		private const uint MalkorokId = 71454;
		private const uint ImplosionId = 71470;

		[EncounterHandler(71454, "Malkorok")]
		public Composite CreateBehavior_Malkorok()
		{
			var roomCenter = new WoWPoint(1914.795, -4950.756, -198.9773);
			WoWPoint rangeSpreadoutPoint = WoWPoint.Zero;
			const float roomRadius = 40;
			WoWPoint breathOfYShaarjMoveTo = WoWPoint.Zero;

			WaitTimer arcingSmashCaptureTimer = null;
			WaitTimer arcingSmashTimer = new WaitTimer(TimeSpan.FromSeconds(10));

			var arcingSmashAngles = new List<ScriptHelpers.AngleSpan>();
			// run away from raid members if has the Displaced Energy debuf
			AddAvoidObject(ctx => Me.HasAura("Displaced Energy"), 15, o => !o.IsMe && o is WoWPlayer);
			// don't pull boss.
			AddAvoidObject(ctx => true, 30, o => o.Entry == MalkorokId && !o.ToUnit().Combat && o.ToUnit().IsAlive);
			//AddAvoidObject(ctx => Me.IsRange(), 15, o => o.Entry == MalkorokId && o.ToUnit().Combat && !o.ToUnit().HasAura(BloodRageSpellId));

			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// initialize the ranged stand at location during phase one.
				new Decorator(
					ctx => rangeSpreadoutPoint == WoWPoint.Zero && Me.IsRange(),
					new Action(
						ctx =>
						{
							rangeSpreadoutPoint = GetRandomPointAroundLocation(roomCenter, 0, 359, 20, roomRadius);
							return RunStatus.Failure;
						})),
				// Ranged phase 1 logic.
				new Decorator(
					ctx =>
						Me.IsRangeDps() && boss.CastingSpellId != BloodRageSpellId && !boss.HasAura(BloodRageSpellId)
						&& boss.CastingSpellId != ArcingSmashSpellId && boss.CastingSpellId != BreathOfYShaarjId
						&& !AvoidanceManager.IsRunningOutOfAvoid,
					// Stand in imploding energy
					new PrioritySelector(
						ctx => GetImplodingEnergyMoveTo(),
						new Decorator<WoWPoint>(
							moveto => moveto != WoWPoint.Zero &&  moveto.DistanceSqr(Me.Location) > 4 * 4,
							new Helpers.Action<WoWUnit>(unit => Navigator.MoveTo(unit.Location))),
						// move to my phase one location.
						new Decorator<WoWPoint>(
							moveto => moveto == WoWPoint.Zero && Me.Location.DistanceSqr(rangeSpreadoutPoint) > 10 * 10,
							new Action(ctx => Navigator.MoveTo(rangeSpreadoutPoint)))
						)),

				// Avoid the Arcing Smash ability
				new Decorator(
					ctx =>
					{
						var ret = boss.CastingSpellId == ArcingSmashSpellId;
						if (ret && arcingSmashCaptureTimer == null)
						{
							arcingSmashCaptureTimer = new WaitTimer(TimeSpan.FromSeconds(1));
							arcingSmashCaptureTimer.Reset();
						}
						else if (!ret)
						{
							arcingSmashCaptureTimer = null;
						}
						return ret;
					},
					new PrioritySelector(
						new Decorator(
							ctx => arcingSmashCaptureTimer.IsFinished && arcingSmashTimer.IsFinished,
							new Action(
								ctx =>
								{
									var angle = (int) WoWMathHelper.RadiansToDegrees(WoWMathHelper.NormalizeRadian(boss.Rotation));
									arcingSmashAngles.Add(new ScriptHelpers.AngleSpan(angle, 60));
									Logger.Write("Saved angle ({0} deg) of Arcing Smash", angle);
									arcingSmashTimer.Reset();
									return RunStatus.Failure;
								})),
						ScriptHelpers.CreateAvoidUnitAnglesBehavior(ctx => true, ctx => boss, new ScriptHelpers.AngleSpan(0, 60)))),
				// Avoid the Breath Of YShaarjId ability
				new Decorator(
					ctx => boss.CastingSpellId == BreathOfYShaarjId && arcingSmashAngles.Any(),
					new Sequence(
						new Action(
							ctx =>
							{
								Logger.Write(
									"Boss is casting Breath of Y'Shaarj and there are {0} saved arcing Smash angles",
									arcingSmashAngles.Count);
								foreach (var ang in arcingSmashAngles)
								{
									Logger.Write("\tAngle: {0}", ang.Angle);
								}
							}),
						new DecoratorContinue(
							ctx => ScriptHelpers.IsLocationInAngleSpans(Me.Location, boss.Location, 0, arcingSmashAngles.ToArray()),
							new Sequence(
								ctx =>
									ScriptHelpers.GetPointOutsideAngleSpans(
										Me.Location,
										boss.Location,
										0,
										roomRadius + 10,
										out breathOfYShaarjMoveTo,
										arcingSmashAngles.ToArray()),
								new DecoratorContinue<bool>(
									success => success,
									ScriptHelpers.CreateMoveToContinue(ctx => true, ctx => breathOfYShaarjMoveTo, true))
								)),
						new Action(ctx => arcingSmashAngles.Clear()))),
				// Phase 2 logic
				// Stack up on tank
				new Decorator(
					ctx =>
						(boss.CastingSpellId == BloodRageSpellId || boss.HasAura(BloodRageSpellId)) && !AvoidanceManager.IsRunningOutOfAvoid,
					new PrioritySelector(
						ctx => ScriptHelpers.Tank,
						new Decorator<WoWPlayer>(
							player => Me.Location.DistanceSqr(player.Location) > 8*8,
							new Helpers.Action<WoWPlayer>(player => Navigator.MoveTo(player.Location)))))
				);
		}

		readonly WaitTimer _implodingEnergyTimer = new WaitTimer(TimeSpan.FromSeconds(2));
		private WoWPoint _lastImplodingEnergyPoint;

		private WoWPoint GetImplodingEnergyMoveTo()
		{
			var implodingEnergy = (from unit in ObjectManager.GetObjectsOfTypeFast<WoWUnit>()
				where unit.Entry == ImplosionId
				let loc = unit.Location
				let myDistSqr = Me.Location.DistanceSqr(loc)
				where myDistSqr <= 20*20 && !ScriptHelpers.GroupMembers.Any(g => g.Guid != Me.Guid && g.Location.DistanceSqr(loc) < 5*5)
				orderby myDistSqr
				select unit).FirstOrDefault();
			if (implodingEnergy != null)
			{
				_implodingEnergyTimer.Reset();
				_lastImplodingEnergyPoint = implodingEnergy.Location;
			}
			else if (_implodingEnergyTimer.IsFinished)
			{
				_lastImplodingEnergyPoint = WoWPoint.Zero;
			}
			return _lastImplodingEnergyPoint;
		}

		private WoWPoint GetRandomPointAroundLocation(WoWPoint point, int startAng, int endAng, float minDist, float maxDist)
		{
			if (endAng < startAng)
				endAng += 360;
			var randomRadians = WoWMathHelper.NormalizeRadian(
				WoWMathHelper.DegreesToRadians(ScriptHelpers.Rnd.Next(startAng, endAng)));
			var randomDist = ScriptHelpers.Rnd.Next((int) minDist, (int) maxDist);
			return point.RayCast(randomRadians, randomDist);
		}

		#endregion

		#region Spoils of Pandoria

		private const uint StoneStatueId = 72535;
		private const uint XiangLinId = 73725;
		private const uint JadeTempestSpellId = 148582;
		private const uint KunDaId = 71408;
		private const uint FractureSpellId = 148513;
		private const uint SetToBlowSpellId = 146365;
		private const uint EncapsulatedPheromonesSpellId = 145285;
		// todo. check out this ability
		private const uint MatterScrambleId = 145369;
		// todo. should probably stand in this.
		private const uint CrimsonReconstitutionSpellId = 145270;
		private const uint MoguRuneOfPowerSpellId = 145460;
		private const int ForbiddenMagicId = 145230;
		private const uint ZarthikAmberPriestId = 71397;
		private const uint WindstormSpellId = 145286;
		private const int HardenFleshSpelId = 144922;
		private const int EarthenShardSpellId = 144923;
		private const uint SparkOfLifeId = 71433;
		private const uint GustingBombSpellId = 145714;
		private const uint ThrowExplosivesMissileId = 145702;
		// this spell needs to be casted when player has 'Set to Blow' aura
		private const int ThrowBombSpellId = 146364;
		private const uint AnimatedStrikeSpellId = 145523;
		private const uint SecuredStockpileOfPandarenSpoilsId = 220823;
		private const uint SecuredStockpileofPandarenSpoilsId = 71889;

		private static readonly Vector2 SopSouthQuadrantCorner = new Vector2(1513.785f, -5093.607f);
		private static readonly Vector2 SopNorthQuadrantCorner = new Vector2(1748.122f, -5155.105f);
		private static readonly Vector2 SopWestQuadrantCorner = new Vector2(1646.395f, -5004.169f);
		private static readonly Vector2 SopEastQuadrantCorner = new Vector2(1617.165f, -5246.308f);
		private static readonly Vector2 SopSouthWestMidPoint = new Vector2(1580.09f, -5048.888f);
		private static readonly Vector2 SopNorthWestMidPoint = new Vector2(1697.259f, -5079.637f);
		private static readonly Vector2 SopNorthEastMidPoint = new Vector2(1682.644f, -5200.707f);
		private static readonly Vector2 SopSouthEastMidPoint = new Vector2(1565.475f, -5169.958f);
		private static readonly Vector2 SopCenterPoint = new Vector2(1631.367f, -5124.798f);

		private readonly DungeonArea _eastQuadrantArea = new DungeonArea(
			SopSouthEastMidPoint,
			SopCenterPoint,
			SopNorthEastMidPoint,
			SopEastQuadrantCorner);

		private readonly DungeonArea _northQuadrantArea = new DungeonArea(
			SopCenterPoint,
			SopNorthWestMidPoint,
			SopNorthQuadrantCorner,
			SopNorthEastMidPoint);

		private readonly DungeonArea _southQuadrantArea = new DungeonArea(
			SopSouthQuadrantCorner,
			SopSouthWestMidPoint,
			SopCenterPoint,
			SopSouthEastMidPoint);

		private readonly WoWPoint _spoilsOfPandaria = new WoWPoint(1631.799, -5125.967, -271.1219);

		private readonly DungeonArea _westQuadrantArea = new DungeonArea(
			SopSouthWestMidPoint,
			SopWestQuadrantCorner,
			SopNorthWestMidPoint,
			SopCenterPoint);

		private WoWPlayer _spoilsOfPandoriaLeader;

		private bool DoingSpoilsOfPandariaEncounter
		{
			get { return GetSecuredStockpileOfPandoriaSpoils() != null; }
		}

		private PosQuadrant GetQuadrantAtLocation(WoWPoint point)
		{
			if (point.Z > -280 || point.Z < -295)
				return PosQuadrant.None;

			if (_southQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.South;

			if (_westQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.West;

			if (_northQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.North;

			if (_eastQuadrantArea.IsPointInPoly(point))
				return PosQuadrant.East;

			return PosQuadrant.None;
		}

		// Todo: get data for Pardaren Relics

		[EncounterHandler(72281, "Spoils of Pandoria", Mode = CallBehaviorMode.Proximity, BossRange = 100)]
		public Composite CreateBehavior_SpoilsOfPandoria()
		{
			// todo figure out the radius of this attack
			AddAvoidObject(ctx => true, 10, o => o.Entry == XiangLinId && o.ToUnit().CastingSpellId == JadeTempestSpellId);

			////  shield that surrounds the chest 
			//AddAvoidObject(
			//	ctx => true,
			//	10,
			//	o => o.Entry == SecuredStockpileofPandarenSpoilsId && o.ToUnit().HasAura("Unstable Defense Systems"));

			AddAvoidObject(
				ctx => true,
				8,
				o => o.Entry == KunDaId && o.ToUnit().CastingSpellId == FractureSpellId,
				o => WoWMathHelper.CalculatePointInFront(o.Location, o.Rotation, 8));

			// run away from raid members so they don't die with me..
			//
			AddAvoidObject(ctx => Me.HasAura("Set to Blow"), 20, o => !o.IsMe && o is WoWPlayer);


			AddAvoidObject(ctx => true, 4, SparkOfLifeId);

			AddAvoidObject(
				ctx => true,
				5,
				o => o.Entry == StoneStatueId && o.ToUnit().CastingSpellId == AnimatedStrikeSpellId,
				o => WoWMathHelper.CalculatePointInFront(o.Location, o.Rotation, 5));

			AddAvoidObject(
				ctx => true,
				3.5f,
				o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == EncapsulatedPheromonesSpellId);


			AddAvoidObject(
				ctx => true,
				o => Me.HasAura("Set to Blow") ? 3 : 7,
				o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == SetToBlowSpellId);


			AddAvoidObject(ctx => true, 3, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == GustingBombSpellId);

			AddAvoidObject(ctx => true, 5, o => o is WoWAreaTrigger && ((WoWAreaTrigger) o).SpellId == WindstormSpellId);

			AddAvoidLocation(
				ctx => true,
				2,
				o => ((WoWMissile) o).ImpactPosition,
				() => WoWMissile.InFlightMissiles.Where(m => m.SpellId == ThrowExplosivesMissileId));

			WoWPoint matterScrableMoveTo = WoWPoint.Zero;

			return new Decorator(
				ctx => ScriptHelpers.IsBossAlive("Spoils of Pandoria"),
				new PrioritySelector(
					ctx =>
					{
						if (_spoilsOfPandoriaLeader == null || !_spoilsOfPandoriaLeader.IsValid )
						{
							_spoilsOfPandoriaLeader = GetSpoilsOfPandoiaLeader();
						}
						matterScrableMoveTo =
							(from missile in WoWMissile.InFlightMissiles
								where missile.SpellId == MatterScrambleId
								let distSqr = missile.ImpactPosition.DistanceSqr(Me.Location)
								where
									distSqr < 20*20 &&
									!GroupMember.GroupMembers.Any(g => g.Guid != Me.Guid && g.Location.DistanceSqr(missile.ImpactPosition) < 4*4)
								orderby distSqr
								select missile.ImpactPosition).FirstOrDefault();

						return _spoilsOfPandoriaLeader;
					},
					new PrioritySelector(
						new Decorator(
							ctx => !Me.Combat && !DoingSpoilsOfPandariaEncounter,
							new PrioritySelector(
								ctx => GetSopGroupLocation(GetSpoilsOfPandoiaLeader(false)),
								new Decorator<WoWPoint>(
									moveto => moveto != WoWPoint.Zero,
									// set POI to my assigned group position.
									// Note: Using Poi here allows bot to rez, buff, and collect consumables if needed.
							
									// ToDO: use Dungeonbot_FollowerMovement TreeHook. this way I don't have to return Success to prevent follow movmment from kicking in and still collect cosumables.
									new PrioritySelector(
										new Decorator<WoWPoint>(
											moveto => moveto.DistanceSqr(Me.Location) > 7*7 && BotPoi.Current.Type == PoiType.None,
											new Helpers.Action<WoWPoint>(moveto => Navigator.MoveTo(moveto))),

										new Decorator<WoWPoint>(
											moveto => moveto.DistanceSqr(Me.Location) <= 7*7,
											new ActionAlwaysSucceed())
										)))),

						// Drop the bombs away from group members.
						new Decorator(
							ctx => Me.HasAura("Set to Blow"),
							new PrioritySelector(
								ctx => SpellActionButton.ExtraActionButton,
								new Decorator(
									ctx =>
										!ScriptHelpers.GroupMembers.Any(
											g => g.Guid != Me.Guid && g.IsAlive && g.Location.DistanceSqr(Me.Location) <= 10*10),
									new PrioritySelector(
										new ActionLogger("Dropping bombs"),
										new Helpers.Action<SpellActionButton>(button => button.Use()))))),
						// handle Matter Scrable
						new Decorator(
							ctx => matterScrableMoveTo != WoWPoint.Zero && Me.IsRangeDps(),
							new Action(ctx => Navigator.MoveTo(matterScrableMoveTo))),

						// handle Matter Scrable
						new Decorator(
							ctx => _spoilsOfPandoriaLeader != null && _spoilsOfPandoriaLeader.IsValid && _spoilsOfPandoriaLeader.IsAlive && _spoilsOfPandoriaLeader.DistanceSqr > 35 * 35,
							new Action(ctx => Navigator.MoveTo(_spoilsOfPandoriaLeader.Location))),

						new PrioritySelector(
							ctx => Me.CurrentTarget,
							new Decorator(
								ctx => ctx != null,
								new PrioritySelector(
									ScriptHelpers.CreateInterruptCast(ctx => (WoWUnit) ctx, HardenFleshSpelId, EarthenShardSpellId),
									// dispell Residue (a HOT) from current target if exists.
									ScriptHelpers.CreateDispellEnemy("Residue", ScriptHelpers.EnemyDispellType.Magic, ctx => (WoWUnit) ctx),
									// dispell Rage of the Empress (damage buff) from current target if exists.
									ScriptHelpers.CreateDispellEnemy("Rage of the Empress", ScriptHelpers.EnemyDispellType.Magic, ctx => (WoWUnit) ctx),
									ScriptHelpers.CreateDispellEnemy("Enrage", ScriptHelpers.EnemyDispellType.Enrage, ctx => (WoWUnit) ctx)
									))),
						// move to a nearby rune for the benefits. Disabled atm do to avoidance issues.
						//new PrioritySelector(
						//	ctx => GetNearbyRuneOfPower(),
						//	new Decorator<WoWAreaTrigger>(
						//		a => a.DistanceSqr > 3*3,
						//		new Helpers.Action<WoWAreaTrigger>(a => Navigator.MoveTo(a.Location)))),
						new Decorator(
							ctx => GetSecuredStockpileOfPandoriaSpoils() == null,
							new Action(ctx => ScriptHelpers.MarkBossAsDead("Spoils of Pandoria")))))
				);
		}

		private WoWPoint GetSopGroupLocation(WoWUnit leader)
		{
			if (leader == null)
				return WoWPoint.Zero;
			var leaderLoc = leader.Location;
			var groupMembersNearLeaderLocations = (from groupMember in ScriptHelpers.GroupMembers
				let loc = groupMember.Location
				where loc.DistanceSqr(leaderLoc) < 15*15
				select loc).ToArray();

			// return WoWPoint.Zero if not enough samples are found
			if (groupMembersNearLeaderLocations.Length < 4)
				return WoWPoint.Zero;

			var groupCenter = groupMembersNearLeaderLocations.Aggregate((a, b) => a + b)/groupMembersNearLeaderLocations.Length;
			if (!Navigator.CanNavigateFully(Me.Location, groupCenter))
				return WoWPoint.Zero;
			return groupCenter;
		}

		private bool IsInMyQuadrants(WoWPoint myLoc, WoWPoint destination)
		{
			return IsInMyQuadrants(GetQuadrantAtLocation(myLoc), destination);
		}

		private bool IsInMyQuadrants(PosQuadrant myQuad, WoWPoint destination)
		{
			if (myQuad == PosQuadrant.None)
				return false;

			var destinationQuad = GetQuadrantAtLocation(destination);
			if (myQuad == PosQuadrant.West || myQuad == PosQuadrant.North)
				return destinationQuad == PosQuadrant.West || destinationQuad == PosQuadrant.North;

			return (myQuad == PosQuadrant.East || myQuad == PosQuadrant.South) &&
					(destinationQuad == PosQuadrant.East || destinationQuad == PosQuadrant.South);
		}

		private WoWUnit GetSecuredStockpileOfPandoriaSpoils()
		{
			return ObjectManager.ObjectList.FirstOrDefault(o => o.Entry == SecuredStockpileofPandarenSpoilsId && o.ToUnit().HasAura("Unstable Defense Systems")) as WoWUnit;
		}

		[EncounterHandler(71393, "Mogu Shadow Ritualist")]
		public Composite CreateBehavior_MoguShadowRitualist()
		{
			WoWUnit boss = null;
			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// interrupt Forbidden Magic cast
				ScriptHelpers.CreateInterruptCast(ctx => boss, ForbiddenMagicId));
		}


		private WoWAreaTrigger GetNearbyRuneOfPower()
		{
			return ObjectManager.GetObjectsOfTypeFast<WoWAreaTrigger>()
				.Where(a => a.SpellId == MoguRuneOfPowerSpellId)
				.OrderBy(a => a.DistanceSqr)
				.FirstOrDefault(
					a =>
					{
						var myTarget = Me.IsHealer ? HealTargeting.Instance.FirstUnit : Targeting.Instance.FirstUnit;
						if (myTarget == null)
							return false;
						var maxRange = Me.IsMeleeDps() ? myTarget.MeleeRange() : 35;
						var pos = a.Location;
						if (Me.Location.Distance(pos) > maxRange)
							return false;
						pos.Z += 1;
						return GameWorld.IsInLineOfSpellSight(pos, myTarget.GetTraceLinePos());
					});
		}

		private WoWPlayer GetSpoilsOfPandoiaLeader(bool eventInProcess = true)
		{
			var tanks = ScriptHelpers.GroupMembers.Where(g => g.IsTank).Select(p => p.Player).ToArray();
			// wait for one of the tanks to drop down into gauntlet before deciding which to follow.
			if (eventInProcess && tanks.All(t => GetQuadrantAtLocation(t.Location) == PosQuadrant.None))
				return null;
			var partyLocs = Me.PartyMembers.Select(p => p.Location).ToList();
			if (!partyLocs.Any())
				partyLocs.Add(Me.Location);
			// return the tank that my party members are nearest to
			return tanks.OrderBy(t => partyLocs.Sum(p => p.Distance(t.Location)/partyLocs.Count)).FirstOrDefault();
		}

		private enum PosQuadrant
		{
			None,
			North,
			East,
			South,
			West
		}

		#endregion

		#region Thok the Bloodthirsty

		private const uint ThokTheBloodthirstyId = 71529;
		private const int FixateSpellId = 143445;
		private const int IceTombId = 71720;
		private const uint BurningBloodSpellId = 143783;

		private readonly WaitTimer _updateRangedGroupCenterPos = WaitTimer.FiveSeconds;
		private WoWPoint _rangedGroupCenter;

		[EncounterHandler(71529, "Thok the Bloodthirsty")]
		public Composite CreateBehavior_ThokTheBloodthirsty()
		{
			// var roomCenter = new WoWPoint(1204.029, -5113.106, -289.3376);
			// const float roomRadius = 79;

			WoWUnit boss = null;

			// run from Thok when fixated or while he's picking a new target.
			AddAvoidObject(
				ctx => Me.HasAura(FixateSpellId),
				40,
				o => o.Entry == ThokTheBloodthirstyId && (o.ToUnit().CastingSpellId == FixateSpellId || Me.HasAura(FixateSpellId)));

			// avoid Thok's front area
			AddAvoidObject(
				ctx => true,
				25,
				o => o.Entry == ThokTheBloodthirstyId && o.ToUnit().IsAlive,
				o => WoWMathHelper.CalculatePointInFront(o.Location, o.Rotation, 25));
			// avoid Thok's back side
			AddAvoidObject(
				ctx => true,
				20,
				o => o.Entry == ThokTheBloodthirstyId && o.ToUnit().IsAlive,
				o => WoWMathHelper.CalculatePointBehind(o.Location, o.Rotation, 20));

			// avoid the fire on ground.
			AddAvoidObject(
				ctx => true,
				3,
				o =>
				{
					var areaTrigger = o as WoWAreaTrigger;
					return areaTrigger != null && areaTrigger.SpellId == BurningBloodSpellId;
				});

			return new PrioritySelector(
				ctx => boss = ctx as WoWUnit,
				// ranged classes should no wander too far from raid. (not a problem for melee)
				new Decorator(
					ctx => Me.IsRange() && !boss.HasAura("Blood Frenzy"),
					new PrioritySelector(
						ctx => GetRangedGroupCenter(),
						new Decorator<WoWPoint>(
							raidPos => Me.Location.DistanceSqr(raidPos) > 10*10,
							new Helpers.Action<WoWPoint>(raidPos => Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(raidPos))))))
				);
		}

		private WoWPoint GetRangedGroupCenter()
		{
			if (_rangedGroupCenter == WoWPoint.Zero || _updateRangedGroupCenterPos.IsFinished)
			{
				_rangedGroupCenter = ScriptHelpers.GetGroupCenterLocation(g => g.IsRange, 20);
				_updateRangedGroupCenterPos.Reset();
			}
			return _rangedGroupCenter;
		}

		#endregion
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Inventory;
using Styx.Helpers;
using Styx.Localization;
using Styx.Plugins;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;


namespace Styx.Bot.Plugins.AutoEquip2
{
    public partial class AutoEquip : HBPlugin
    {
        #region Overrides of HBPlugin

        /// <summary>Enables this plugin.</summary>
        public override void OnEnable()
        {
        }

        /// <summary>Disables this plugin.</summary>
        public override void OnDisable()
        {
        }

        /// <summary>
        /// The text of the button if the plugin wants it. [Default: "Settings"]
        /// </summary>
        public override string ButtonText { get { return "Configuration"; } }

        /// <summary>
        /// Does this plugin want a button? If set to true, the button in the plugin manager will be enabled. [Default: false]
        /// </summary>
        public override bool WantButton { get { return true; } }

        /// <summary>
        /// Called when the user presses the button while having this plugin selected. The plugin can start a thread, show a form, or just do what the hell it wants.
        /// </summary>
		public override void OnButtonPress()
		{
			MessageBox.Show("AutoEquip has been integrated with Honorbuddy. Please open the Honorbuddy settings window and check under Character Manager.", "Notice", MessageBoxButton.OK,
				MessageBoxImage.Information);
		}
        /// <summary>
        /// Called everytime the engine pulses.
        /// </summary>
        public override void Pulse()
        {
        }

        /// <summary>
        /// The name of this plugin.
        /// </summary>
        public override string Name { get { return Globalization.AutoEquip_Name; } }

        /// <summary>
        /// The author of this plugin.
        /// </summary>
        public override string Author { get { return "The Buddy Team"; } }

        /// <summary>
        /// The version of the plugin.
        /// </summary>
        public override Version Version { get { return new Version(2, 0, 0); } }

        #endregion
    }
}
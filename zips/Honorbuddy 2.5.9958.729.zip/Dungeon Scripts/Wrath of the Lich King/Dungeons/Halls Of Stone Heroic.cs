﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bots.DungeonBuddy.Dungeon_Scripts.Wrath_of_the_Lich_King
{
    public class HallsOfStoneHeroic : HallsOfStone
    {
        public override uint DungeonId
        {
            get { return 213; }
        }
    }
}

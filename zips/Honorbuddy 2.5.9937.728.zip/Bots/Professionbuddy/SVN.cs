﻿// This file is auto genorated from using SubRCRev.exe and template SVN.template
// Build Date: 2014/02/15 12:42:29
// SVN url: https://professionbuddy.googlecode.com/svn/trunk/Professionbuddy

namespace HighVoltz
{
    public partial class Svn
    {
        protected override string RevString
        {
            get
            {
                return "641";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Inventory;
using Styx.Helpers;
using Styx.Localization;
using Styx.Plugins;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Talented
{
    public class Talented : HBPlugin
    {
        public override void Pulse()
        {
        }

        public override string Name { get { return Globalization.Talented_Name; } }

        public override string Author { get { return "The Buddy Team"; } }

        public override Version Version { get { return new Version(2, 0, 0); } }

        public override bool WantButton { get { return true; } }

        public override string ButtonText { get { return "Select Talent Build"; } }

        public override void OnButtonPress()
        {
			MessageBox.Show("Talented has been integrated with Honorbuddy. Please open the Honorbuddy settings window and check under Character Manager.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}

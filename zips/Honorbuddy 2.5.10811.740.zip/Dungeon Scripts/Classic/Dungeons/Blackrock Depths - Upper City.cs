﻿namespace Bots.DungeonBuddy.Dungeon_Scripts.Classic
{
	public class BlackrockDepthsUpperCity : BlackrockDepthsDetentionBlock
	{
		public override uint DungeonId { get { return 276; } }
	}
}